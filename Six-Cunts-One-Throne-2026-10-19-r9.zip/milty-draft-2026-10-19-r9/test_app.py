import os,tempfile,unittest,concurrent.futures,copy
fd,PATH=tempfile.mkstemp();os.close(fd)
os.environ['STORAGE']='sqlite';os.environ['SQLITE_PATH']=PATH
from app import app,load
from engine import slices,TILES,COORDS,distance,FACTIONS,turn,slice_pool,TE_COMPONENTS,factions_for
class DraftTests(unittest.TestCase):
 def setUp(self):
  self.c=app.test_client();res=self.c.post('/api/rooms',json={'names':['Cameron','Hannah','Ryan','Martin','Nathan','George'],'title':'Test'})
  self.assertEqual(res.status_code,201);d=res.get_json();self.code=d['code'];self.host=d['token'];self.room=d['room'];self.tokens=['player-'+str(i)+'x'*40 for i in range(6)]
 def post(self,b,t=None):
  b={'revision':self.room['revision'],**b};r=self.c.post('/api/rooms/'+self.code,json=b,headers={'Authorization':'Bearer '+(t or self.host)})
  if r.status_code==200:self.room=r.get_json()
  return r
 def claim_all(self):
  for i,t in enumerate(self.tokens):self.assertEqual(self.post({'action':'claim','player':i},t).status_code,200)
 def test_full_async_draft(self):
  self.assertNotIn('host',self.room);self.assertNotIn('claim',self.room['players'][0]);self.claim_all();self.assertEqual(self.post({'action':'start'}).status_code,200)
  expected=list(range(6))+list(reversed(range(6)))+list(range(6))
  for step,i in enumerate(expected):
   self.assertEqual(self.room['turn'],i);kind=['faction','slice','seat'][step//6];value=FACTIONS[i]['id'] if kind=='faction' else str(i) if kind=='slice' else str(i+1)
   self.assertEqual(self.post({'action':'pick','kind':kind,'value':value},self.tokens[i]).status_code,200)
   # Read through a completely new browser connection between every pick.
   remote=app.test_client().get('/api/rooms/'+self.code).get_json();self.assertEqual(remote,self.room)
  self.assertIsNone(self.room['turn']);self.assertEqual(len(self.room['history']),18)
  self.assertEqual(self.post({'action':'undo'}).status_code,200);self.assertEqual(self.room['turn'],5)
  self.assertEqual(self.post({'action':'pick','kind':'seat','value':'6'},self.tokens[5]).status_code,200)
 def test_authorization_and_stale_revision(self):
  self.assertEqual(self.post({'action':'start'},self.tokens[0]).status_code,403)
  self.assertEqual(self.post({'action':'start'}).status_code,400)
  self.claim_all();self.assertEqual(self.post({'action':'claim','player':0},'z'*40).status_code,400)
  self.post({'action':'start'});self.assertEqual(self.post({'action':'pick','kind':'slice','value':'0'},self.tokens[1]).status_code,403)
  stale=self.room['revision'];self.post({'action':'pick','kind':'slice','value':'0'},self.tokens[0])
  self.assertEqual(self.post({'action':'pick','kind':'slice','value':'1','revision':stale},self.tokens[1]).status_code,400)
  self.assertEqual(self.post({'action':'pick','kind':'slice','value':'0'},self.tokens[1]).status_code,400)
  self.assertEqual(self.post({'action':'reroll'}).status_code,400)
 def test_simultaneous_claim(self):
  revision=self.room['revision']
  def claim(token):
   with app.test_client() as c:return c.post('/api/rooms/'+self.code,json={'action':'claim','player':0,'revision':revision},headers={'Authorization':'Bearer '+token}).status_code
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(claim,['a'*40,'b'*40]))
  self.assertEqual(sorted(result),[200,400])
 def test_recovery_and_release(self):
  self.claim_all();self.post({'action':'release','player':0});self.assertEqual(self.post({'action':'claim','player':0},'new-device-key'+'x'*40).status_code,200)
  saved=load(self.code);self.assertEqual(saved['revision'],self.room['revision']);self.assertEqual(saved['players'][0]['name'],self.room['players'][0]['name'])
 def test_slice_generator(self):
  for _ in range(100):
   result=slices();all_ids=[t for s in result for t in s['tiles']];self.assertEqual(len(set(all_ids)),35)
   for s in result:
    self.assertEqual(sum(TILES[t]['type']=='blue' for t in s['tiles']),3)
    self.assertEqual(sum(TILES[t]['type']=='red' for t in s['tiles']),2)
    self.assertGreaterEqual(s['stats']['resources'],4);self.assertGreaterEqual(s['stats']['influence'],4)
    for i,a in enumerate(s['tiles']):
     for j,b in enumerate(s['tiles']):
      if i<j and TILES[a]['anomaly'] and TILES[b]['anomaly']:self.assertNotEqual(distance(COORDS[i],COORDS[j]),1)
 def test_static_assets(self):
  for path in ('/','/static/app.js','/static/style.css','/healthz','/api/data'):
   response=self.c.get(path);self.assertEqual(response.status_code,200);self.assertEqual(response.headers['X-Content-Type-Options'],'nosniff');response.close()
  self.assertEqual(len(self.c.get('/api/data').get_json()['factions']),30)
 def test_thunders_edge_catalog(self):
  self.assertEqual(len(FACTIONS),30)
  self.assertEqual(len([f for f in FACTIONS if f['expansion']=='te']),5)
  self.assertEqual({str(i) for i in range(97,118)}-{'112'},set(slice_pool())-set(slice_pool(False)))
  for id in ('112','118','96A','96B','94'):
   self.assertNotIn(id,slice_pool())
  self.assertEqual(len([t for t in slice_pool().values() if t['type']=='blue']),51)
  self.assertEqual(len([t for t in slice_pool().values() if t['type']=='red']),23)
  self.assertEqual(len(TE_COMPONENTS['fracture']),3)
  self.assertEqual(sum(len(t['systems']) for t in TE_COMPONENTS['fracture']),7)
  self.assertEqual(len(TE_COMPONENTS['hyperlanes']),12)
  self.assertTrue(self.room['settings']['thundersEdge'])
  self.assertEqual(self.room['settings']['centerTile'],'112')
 def test_disable_expansion_and_legacy_rooms(self):
  from engine import act,new_room,digest
  room=new_room(['A','B','C','D','E','F'],'Base game',False)
  self.assertEqual(len(factions_for(room)),25)
  self.assertEqual(room['settings']['centerTile'],'18')
  for s in room['slices']:
   self.assertTrue(all(TILES[t]['expansion']!='te' for t in s['tiles']))
  room['started']=True;room['players'][0]['claim']=digest('test-player-key')
  with self.assertRaises(ValueError):act(room,{'action':'pick','kind':'faction','value':'94','revision':0},'test-player-key')
  room.pop('settings');self.assertEqual(len(factions_for(room)),25)
 def test_new_factions_can_be_drafted(self):
  self.claim_all();self.post({'action':'start'})
  for i,id in enumerate(['92','93','94','95','96A','keleres']):
   self.assertEqual(self.post({'action':'pick','kind':'faction','value':id},self.tokens[i]).status_code,200)
  self.assertEqual(self.room['players'][4]['faction'],'96A')
 def test_expansion_boolean_validation(self):
  response=self.c.post('/api/rooms',json={'names':['a']*6,'thundersEdge':'false'})
  self.assertEqual(response.status_code,400)
 def test_tech_icons_do_not_count_stations_or_legendary(self):
  from engine import stats
  self.assertEqual(stats(['109'])['skips'],0)
  self.assertEqual(stats(['101'])['skips'],2)
  self.assertEqual(stats(['107'])['skips'],2)
  self.assertEqual(stats(['97'])['skips'],1)
  self.assertEqual(stats(['109'])['stations'],1)
 def test_configurable_bounds_and_exact_legendary_total(self):
  from engine import slices,stats
  cfg={'resourcesMin':7,'resourcesMax':10,'influenceMin':7,'influenceMax':10,'legendaryMin':0,'legendaryMax':1,'legendaryTotalMin':3,'legendaryTotalMax':3,'connectedWormholes':True}
  for enabled in (True,False):
   local={**cfg,'legendaryTotalMin':2,'legendaryTotalMax':2} if not enabled else cfg
   for _ in range(15):
    generated=slices(enabled,local)
    self.assertEqual(len({i for s in generated for i in s['tiles']}),35)
    self.assertEqual(sum(s['stats']['legendaries'] for s in generated),local['legendaryTotalMin'])
    for s in generated:
     self.assertTrue(7<=s['stats']['resources']<=10)
     self.assertTrue(7<=s['stats']['influence']<=10)
     self.assertLessEqual(s['stats']['legendaries'],1)
    for omitted in range(7):
     final=[s for n,s in enumerate(generated) if n!=omitted]
     for w in ('alpha','beta'):
      self.assertGreaterEqual(sum(any(w in TILES[i]['wormhole'] for i in s['tiles']) for s in final),2)
 def test_zero_and_one_per_slice_legendaries(self):
  from engine import slices
  zero=slices(True,{'legendaryMax':0})
  self.assertEqual(sum(s['stats']['legendaries'] for s in zero),0)
  seven=slices(True,{'legendaryMin':1,'legendaryMax':1,'legendaryTotalMin':7,'legendaryTotalMax':7,'connectedWormholes':True})
  self.assertTrue(all(s['stats']['legendaries']==1 for s in seven))
 def test_invalid_setup_ranges_and_bans(self):
  from engine import normalize_options
  cases=[{'resourcesMin':12,'resourcesMax':5},{'influenceMin':8,'influenceMax':2},{'legendaryMin':2},{'legendaryTotalMin':8},{'resourcesMax':-1},{'resourcesMin':True},{'resourcesMax':8.5},{'connectedWormholes':'yes'},{'unknown':1},{'resourcesMin':100}]
  for cfg in cases:
   with self.subTest(cfg=cfg):
    with self.assertRaises(ValueError):normalize_options(True,[],cfg)
  for bans in ([f['id'] for f in FACTIONS],['nonexistent'],'92',[True]):
   with self.assertRaises(ValueError):normalize_options(True,bans,{})
  with self.assertRaises(ValueError):normalize_options(False,['94'],{})
 def test_bans_and_host_setup_persist_and_lock(self):
  response=self.post({'action':'configure','bannedFactions':['92','keleres'],'sliceLimits':{'resourcesMin':7,'resourcesMax':10,'influenceMin':7,'influenceMax':10,'legendaryTotalMin':3,'legendaryTotalMax':3,'connectedWormholes':True}})
  self.assertEqual(response.status_code,200)
  self.assertEqual(self.room['settings']['bannedFactions'],['92','keleres'])
  self.assertNotIn('92',[f['id'] for f in factions_for(self.room)])
  self.post({'action':'reroll'})
  self.assertEqual(sum(s['stats']['legendaries'] for s in self.room['slices']),3)
  self.assertTrue(self.room['settings']['sliceLimits']['connectedWormholes'])
  self.assertEqual(app.test_client().get('/api/rooms/'+self.code).get_json()['settings'],self.room['settings'])
  self.claim_all();self.post({'action':'start'})
  self.assertEqual(self.post({'action':'pick','kind':'faction','value':'92'},self.tokens[0]).status_code,400)
  self.assertEqual(self.post({'action':'configure','bannedFactions':[]}).status_code,400)
 def test_failed_configuration_is_atomic(self):
  original=copy.deepcopy(self.room)
  self.assertEqual(self.post({'action':'configure','bannedFactions':['92'],'sliceLimits':{'legendaryMin':2}}).status_code,400)
  self.assertEqual(self.c.get('/api/rooms/'+self.code).get_json(),original)
  self.assertEqual(self.post({'action':'configure'},self.tokens[0]).status_code,403)
 def test_setup_at_creation(self):
  response=self.c.post('/api/rooms',json={'names':['a','b','c','d','e','f'],'bannedFactions':['92'],'sliceLimits':{'legendaryTotalMin':0,'legendaryTotalMax':0,'resourcesMax':10,'connectedWormholes':True}})
  self.assertEqual(response.status_code,201)
  room=response.get_json()['room']
  self.assertEqual(room['settings']['bannedFactions'],['92'])
  self.assertTrue(all(s['stats']['legendaries']==0 and s['stats']['resources']<=10 for s in room['slices']))
 def test_all_systems_have_consistent_arrays(self):
  for id,t in TILES.items():
   for key in ('anomaly','wormhole'):
    with self.subTest(tile=id,field=key):self.assertIsInstance(t[key],list)
  self.assertEqual(TILES['51']['wormhole'],['delta'])
  self.assertEqual(TILES['82']['anomaly'],[])
 def test_slice_viewbox_contains_every_hex_vertex(self):
  import math,re
  from pathlib import Path
  source=(Path(__file__).parent/'static/app.js').read_text()
  view=re.search(r'function sliceSvg.*?viewBox="([^"]+)"',source).group(1)
  left,top,width,height=map(float,view.split())
  for q,r in COORDS+[(0,-3)]:
   q,r=-q,-r
   cx=52.5*q;cy=35*math.sqrt(3)*(r+q/2)
   for i in range(6):
    angle=math.radians(60*i);x=cx+35*math.cos(angle);y=cy+35*math.sin(angle)
    self.assertGreaterEqual(x,left+2);self.assertLessEqual(x,left+width-2)
    self.assertGreaterEqual(y,top+2);self.assertLessEqual(y,top+height-2)
 def test_milty_slice_topology(self):
  home=(0,-3);mecatol=(0,0);next_home=(3,-3)
  self.assertEqual(sum(distance(c,home)==1 for c in COORDS),3)
  self.assertEqual(sum(distance(c,mecatol)==1 for c in COORDS),1)
  equidistant=[c for c in COORDS if distance(c,home)==2 and distance(c,next_home)==2]
  self.assertEqual(equidistant,[(1,-2)])
  self.assertEqual(set(c for c in COORDS if distance(c,home)==1),{(0,-2),(1,-3),(-1,-2)})
 def test_browser_and_generator_use_same_geometry(self):
  import re,json
  from pathlib import Path
  source=(Path(__file__).parent/'static/app.js').read_text()
  browser=json.loads(re.search(r'const coords=(\[.*?\]);',source).group(1))
  self.assertEqual(browser,[list(c) for c in COORDS])
 def test_manual_order_on_creation(self):
  names=['A','B','C','D','E','F']
  response=self.c.post('/api/rooms',json={'names':names,'orderMode':'manual'})
  self.assertEqual(response.status_code,201)
  room=response.get_json()['room'];self.assertEqual([p['name'] for p in room['players']],names)
  self.assertEqual(room['settings']['orderMode'],'manual')
  self.assertEqual(room['draftOrder'],list(range(6)))
  self.assertEqual(self.c.post('/api/rooms',json={'names':names,'orderMode':'bad'}).status_code,400)
 def test_host_order_preserves_claims_and_turn_sequence(self):
  self.claim_all();original=[p['name'] for p in self.room['players']]
  order=[5,2,4,1,0,3]
  self.assertEqual(self.post({'action':'order','order':order}).status_code,200)
  self.assertEqual([p['name'] for p in self.room['players']],original)
  self.assertTrue(all(p['claimed'] for p in self.room['players']))
  self.assertEqual(self.post({'action':'order','order':[0]*6}).status_code,400)
  self.assertEqual(self.post({'action':'order','order':order},self.tokens[0]).status_code,403)
  self.post({'action':'start'})
  expected=order+list(reversed(order))+order
  for n,i in enumerate(expected):
   self.assertEqual(self.room['turn'],i)
   kind=['faction','slice','seat'][n//6]
   value=FACTIONS[i]['id'] if kind=='faction' else str(i) if kind=='slice' else str(i+1)
   self.assertEqual(self.post({'action':'pick','kind':kind,'value':value},self.tokens[i]).status_code,200)
  self.assertEqual(self.post({'action':'order','randomize':True}).status_code,400)
 def test_randomize_lobby_order(self):
  self.assertEqual(self.post({'action':'order','randomize':True}).status_code,200)
  self.assertEqual(sorted(self.room['draftOrder']),list(range(6)))
 def test_global_anomaly_rule_for_any_seat_assignment(self):
  from engine import rotate_coord
  for te in (True,False):
   for _ in range(5):
    generated=slices(te,{'noAdjacentAnomalies':True,'connectedWormholes':True})
    for a in generated:
     anomalies=[COORDS[i] for i,t in enumerate(a['tiles']) if TILES[t]['anomaly']]
     for x in anomalies:
      for n in range(6):self.assertNotEqual(distance(x,rotate_coord((0,-3),n)),1)
     for b in generated:
      if a is b:continue
      other=[COORDS[i] for i,t in enumerate(b['tiles']) if TILES[t]['anomaly']]
      for n in range(1,6):
       for x in anomalies:
        for y in other:self.assertNotEqual(distance(x,rotate_coord(y,n)),1)
 def test_video_streaming_and_javascript_syntax(self):
  import shutil,subprocess
  from pathlib import Path
  response=self.c.get('/static/draft-intro.mp4',headers={'Range':'bytes=0-1023'})
  self.assertEqual(response.status_code,206);self.assertEqual(len(response.data),1024)
  self.assertIn("media-src 'self'",response.headers['Content-Security-Policy']);response.close()
  page=self.c.get('/');self.assertIn(b'/static/draft-intro.mp4',page.data);page.close()
  if shutil.which('node'):
   result=subprocess.run(['node','--check',str(Path(__file__).parent/'static/app.js')],capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr)
 def test_artwork_for_every_draftable_system(self):
  catalog=self.c.get('/api/data').get_json()
  for id in slice_pool():
   self.assertIn(id,catalog['tileArt'])
  for f in FACTIONS:
   if f['home']:self.assertIn(f['home'],catalog['tileArt'])
  for id,url in catalog['tileArt'].items():
   response=self.c.get(url)
   self.assertEqual(response.status_code,200)
   self.assertEqual(response.data[:4],b'RIFF')
   self.assertEqual(response.data[8:12],b'WEBP');response.close()
 def test_tiamat_matches_tile_art_and_stored_stats_refresh(self):
  from engine import stats,public
  p=TILES['107']['planets'][0]
  self.assertEqual((p['resources'],p['influence']),(1,2))
  from app import load
  room=load(self.code);room['slices'][0]['tiles'][0]='107';room['slices'][0]['stats']['resources']=-1
  visible=public(room)
  self.assertEqual(visible['slices'][0]['stats'],stats(room['slices'][0]['tiles']))
 def test_release_identity(self):
  from pathlib import Path
  expected=(Path(__file__).parent/'VERSION').read_text().strip()
  self.assertEqual(self.c.get('/healthz').get_json()['version'],expected)
  response=self.c.get('/');self.assertIn(('Release '+expected).encode(),response.data);response.close()
 def test_excluded_systems_never_generate(self):
  from engine import normalize_options
  cfg={'excludedTiles':['115','105'],'legendaryTotalMin':3,'legendaryTotalMax':3,'connectedWormholes':True}
  for _ in range(15):
   result=slices(True,cfg);ids={i for s in result for i in s['tiles']}
   self.assertTrue(ids.isdisjoint({'115','105'}))
   self.assertEqual(sum(s['stats']['legendaries'] for s in result),3)
  six=slices(True,{'excludedTiles':['115'],'legendaryTotalMin':6,'legendaryTotalMax':6})
  self.assertEqual(sum(s['stats']['legendaries'] for s in six),6)
  with self.assertRaises(ValueError):normalize_options(True,[],{'excludedTiles':['115'],'legendaryTotalMin':7,'legendaryTotalMax':7})
 def test_exclusion_validation_and_wormhole_conflict(self):
  from engine import normalize_options
  for excluded in ('115',[115],['112'],['92'],['missing']):
   with self.subTest(excluded=excluded):
    with self.assertRaises(ValueError):normalize_options(True,[],{'excludedTiles':excluded})
  with self.assertRaises(ValueError):normalize_options(False,[],{'excludedTiles':['115']})
  with self.assertRaises(ValueError):normalize_options(False,[],{'excludedTiles':['40'],'connectedWormholes':True})
  blue=[i for i,t in slice_pool().items() if t['type']=='blue']
  with self.assertRaises(ValueError):normalize_options(True,[],{'excludedTiles':blue})
 def test_exclusions_survive_lobby_apply_regeneration_and_reload(self):
  self.assertEqual(self.post({'action':'configure','sliceLimits':{'excludedTiles':['115','115']}}).status_code,200)
  self.assertEqual(self.room['settings']['sliceLimits']['excludedTiles'],['115'])
  self.post({'action':'reroll'})
  self.assertTrue(all('115' not in s['tiles'] for s in self.room['slices']))
  reloaded=self.c.get('/api/rooms/'+self.code).get_json()
  self.assertEqual(reloaded['settings']['sliceLimits']['excludedTiles'],['115'])
  before=copy.deepcopy(reloaded)
  self.assertEqual(self.post({'action':'configure','sliceLimits':{'excludedTiles':['115'],'legendaryTotalMin':7}}).status_code,400)
  self.assertEqual(self.c.get('/api/rooms/'+self.code).get_json(),before)
 def test_strength_is_opportunity_cost_and_position_aware(self):
  from engine import strength
  weak=['46','19','35','47','20'];strong=['46','35','19','47','20']
  a=strength(weak);b=strength(strong)
  self.assertGreater(b['score'],a['score'])
  self.assertAlmostEqual(sum(a['weightedSpend'].values()),a['breakdown']['economy'],delta=0.02)
  self.assertEqual(a['model'],'overall-v1')
  self.assertEqual(strength(['43','19','35','47','20'])['breakdown']['routes'],-2.5)
 def test_balancing_is_optional_and_off_by_default(self):
  from engine import DEFAULT_LIMITS,slices
  from unittest.mock import patch
  self.assertFalse(DEFAULT_LIMITS['balanceStrength'])
  with patch('engine.strength',side_effect=AssertionError('Must not score ordinary generation')):
   result=slices(True,{})
  self.assertTrue(all('balance' not in s for s in result))
  self.assertFalse(self.room['settings']['sliceLimits']['balanceStrength'])
 def test_balance_selection_never_worse_than_first_valid_candidate(self):
  from engine import slices,balance_quality
  import random
  state=random.getstate()
  try:
   for seed in (11,22,33):
    random.seed(seed);ordinary=slices(True,{})
    random.seed(seed);balanced=slices(True,{'balanceStrength':True})
    self.assertLessEqual(balance_quality(balanced),balance_quality(ordinary)+1e-9)
    self.assertGreater(balanced[0]['balanceSearch']['candidatesCompared'],1)
    self.assertTrue(all(s['balance']['model']=='overall-v1' for s in balanced))
  finally:random.setstate(state)
 def test_balancing_preserves_all_user_constraints(self):
  from engine import slices,rotate_coord
  cfg={'balanceStrength':True,'resourcesMin':7,'resourcesMax':10,'influenceMin':7,'influenceMax':10,'legendaryTotalMin':3,'legendaryTotalMax':3,'connectedWormholes':True,'noAdjacentAnomalies':True,'excludedTiles':['115']}
  generated=slices(True,cfg)
  self.assertEqual(sum(s['stats']['legendaries'] for s in generated),3)
  self.assertEqual(len({id for s in generated for id in s['tiles']}),35)
  for s in generated:
   self.assertNotIn('115',s['tiles'])
   self.assertTrue(7<=s['stats']['resources']<=10)
   self.assertTrue(7<=s['stats']['influence']<=10)
  for omitted in range(7):
   retained=[s for n,s in enumerate(generated) if n!=omitted]
   for w in ('alpha','beta'):self.assertGreaterEqual(sum(any(w in TILES[i]['wormhole'] for i in s['tiles']) for s in retained),2)
  for a in generated:
   for b in generated:
    if a is b:continue
    for n in range(1,6):
     for i,x in enumerate(a['tiles']):
      for j,y in enumerate(b['tiles']):
       if TILES[x]['anomaly'] and TILES[y]['anomaly']:self.assertNotEqual(distance(COORDS[i],rotate_coord(COORDS[j],n)),1)
 def test_balance_option_persists_and_can_be_turned_off(self):
  self.assertEqual(self.post({'action':'configure','sliceLimits':{'balanceStrength':True}}).status_code,200)
  self.assertTrue(self.room['settings']['sliceLimits']['balanceStrength'])
  self.assertIn('balanceSearch',self.room['slices'][0])
  self.post({'action':'reroll'})
  self.assertIn('balanceSearch',self.room['slices'][0])
  self.assertEqual(self.post({'action':'configure','sliceLimits':{'balanceStrength':False}}).status_code,200)
  self.assertTrue(all('balance' not in s for s in self.room['slices']))
  self.assertEqual(self.post({'action':'configure','sliceLimits':{'balanceStrength':'true'}}).status_code,400)
 def test_map_geometry(self):
  def rot(q,r,n):
   for _ in range(n):q,r=-r,q+r
   return q,r
  points=[(0,0)]+[rot(*c,n) for n in range(6) for c in COORDS+[(0,-3)]]
  self.assertEqual(len(set(points)),37)
if __name__=='__main__':unittest.main(verbosity=2)
