import json, random, secrets, hashlib, copy
from pathlib import Path
TILES=json.loads((Path(__file__).parent/'data/tiles.json').read_text())
TE_COMPONENTS=json.loads((Path(__file__).parent/'data/thunders-edge.json').read_text())
FACTIONS=[{'id':str(k),'name':v['faction'],'home':str(k),'expansion':v['expansion']} for k,v in TILES.items() if v['type']=='green' and k.isdigit() and int(k)<=58 and int(k)!=51]
FACTIONS.append({'id':'keleres','name':'The Council Keleres','home':None,'expansion':'codex'})
FACTIONS.extend([
 {'id':'92','name':'Last Bastion','home':'92','expansion':'te'},
 {'id':'93','name':'The Ral Nel Consortium','home':'93','expansion':'te'},
 {'id':'94','name':'The Crimson Rebellion','home':'94','additionalHome':'118','expansion':'te'},
 {'id':'95','name':'The Deepwrought Scholarate','home':'95','expansion':'te'},
 {'id':'96A','name':'The Firmament / The Obsidian','home':'96A','reverseHome':'96B','expansion':'te'}
])
def thunder_enabled(room): return room.get('settings',{}).get('thundersEdge',False)
def factions_for(room): return [f for f in FACTIONS if (thunder_enabled(room) or f['expansion']!='te') and f['id'] not in room.get('settings',{}).get('bannedFactions',[])]
def slice_pool(thunder_edge=True,excluded=()):
    return {i:t for i,t in TILES.items() if i not in excluded and t['type'] in ('blue','red') and not t.get('special') and (thunder_edge or t['expansion']!='te')}
COORDS=[(0,-1),(0,-2),(1,-2),(1,-3),(-1,-2)]
def distance(a,b):
    q,r=a[0]-b[0],a[1]-b[1]
    return max(abs(q),abs(r),abs(q+r))
def stats(ids):
    planets=[p for i in ids for p in TILES[i]['planets']]
    return {'resources':sum(p['resources'] for p in planets),'influence':sum(p['influence'] for p in planets),'effective':sum(max(p['resources'],p['influence']) for p in planets),'planets':len(planets),'skips':sum(sum(s in ('biotic','warfare','propulsion','cybernetic') for s in p['specialty']) for p in planets),'legendaries':sum('legendary' in p['specialty'] for p in planets),'stations':sum('space-station' in p['specialty'] for p in planets)}
DEFAULT_LIMITS={'resourcesMin':4,'resourcesMax':16,'influenceMin':4,'influenceMax':18,'legendaryMin':0,'legendaryMax':1,'legendaryTotalMin':0,'legendaryTotalMax':7,'connectedWormholes':False,'noAdjacentAnomalies':False,'balanceStrength':False,'excludedTiles':[]}
def normalize_options(thunder_edge,banned=None,limits=None):
    if banned is None: banned=[]
    if not isinstance(banned,list) or any(not isinstance(v,str) for v in banned): raise ValueError('Faction bans must be a list of faction IDs.')
    enabled={f['id'] for f in FACTIONS if thunder_edge or f['expansion']!='te'}
    if any(v not in enabled for v in banned): raise ValueError('A banned faction is not enabled in this room.')
    banned=sorted(set(banned))
    if len(enabled)-len(banned)<6: raise ValueError('Leave at least six factions available.')
    if limits is None: limits={}
    if not isinstance(limits,dict) or set(limits)-set(DEFAULT_LIMITS): raise ValueError('Unknown slice limit setting.')
    cfg={**DEFAULT_LIMITS,**limits}
    for flag in ('connectedWormholes','noAdjacentAnomalies','balanceStrength'):
        if not isinstance(cfg[flag],bool): raise ValueError(f'{flag} must be true or false.')
    for key in DEFAULT_LIMITS:
        if key not in ('connectedWormholes','noAdjacentAnomalies','balanceStrength','excludedTiles') and (type(cfg[key]) is not int or not 0<=cfg[key]<=100): raise ValueError('Slice limits must be whole numbers from 0 to 100.')
    for name in ('resources','influence','legendary','legendaryTotal'):
        if cfg[name+'Min']>cfg[name+'Max']: raise ValueError(f'{name} minimum cannot exceed its maximum.')
    excluded=cfg['excludedTiles']
    if not isinstance(excluded,list) or any(not isinstance(i,str) for i in excluded): raise ValueError('Excluded systems must be a list of tile IDs.')
    enabled_tiles=slice_pool(thunder_edge)
    if any(i not in enabled_tiles for i in excluded): raise ValueError('Only enabled, ordinary draft systems can be excluded.')
    cfg['excludedTiles']=sorted(set(excluded))
    pool=slice_pool(thunder_edge,cfg['excludedTiles'])
    if sum(t['type']=='blue' for t in pool.values())<21 or sum(t['type']=='red' for t in pool.values())<14: raise ValueError('Exclusions leave too few systems: seven unique slices need at least 21 blue and 14 red tiles.')
    count=sum(stats([i])['legendaries'] for i in pool)
    if cfg['legendaryMax']>5: raise ValueError('A five-system slice can contain at most five legendary planets.')
    low=max(cfg['legendaryTotalMin'],7*cfg['legendaryMin']); high=min(cfg['legendaryTotalMax'],7*cfg['legendaryMax'],count)
    if low>high: raise ValueError(f'Legendary limits are impossible: only {count} eligible legendary planets are available across seven slices.')
    for attr in ('resources','influence'):
        amounts={kind:sorted((stats([i])[attr] for i,t in pool.items() if t['type']==kind),reverse=True) for kind in ('blue','red')}
        maximum=sum(amounts['blue'][:3])+sum(amounts['red'][:2])
        minimum=sum(amounts['blue'][-3:])+sum(amounts['red'][-2:])
        if cfg[attr+'Min']>maximum or cfg[attr+'Max']<minimum: raise ValueError(f'The {attr} range is impossible for three blue and two red systems.')
        if 7*cfg[attr+'Min']>sum(amounts['blue'][:21])+sum(amounts['red'][:14]): raise ValueError(f'Not enough total {attr} in the tile pool for seven slices at that minimum.')
        if 7*cfg[attr+'Max']<sum(amounts['blue'][-21:])+sum(amounts['red'][-14:]): raise ValueError(f'The {attr} maximum is too low for seven unique slices from this tile pool.')
    if cfg['connectedWormholes'] and any(sum(w in t['wormhole'] for t in pool.values())<3 for w in ('alpha','beta')): raise ValueError('The tile pool cannot guarantee matching alpha and beta wormholes after one slice is omitted.')
    return banned,cfg

def wormholes_connected(result):
    # Three distinct offered slices per type means at least two survive any omission.
    return all(sum(any(w in TILES[i]['wormhole'] for i in s['tiles']) for s in result)>=3 for w in ('alpha','beta'))

def rotate_coord(c,n):
    q,r=c
    for _ in range(n):q,r=-r,q+r
    return q,r
CROSS_ADJACENT={(i,j) for i,a in enumerate(COORDS) for j,b in enumerate(COORDS) if any(distance(a,rotate_coord(b,n))==1 for n in range(1,6))}
def compatible_anomalies(a,b):
    return not any(TILES[a[i]]['anomaly'] and TILES[b[j]]['anomaly'] for i,j in CROSS_ADJACENT)
def _generate_set(thunder_edge=True,limits=None,_deadline=None):
    import time,itertools
    _,cfg=normalize_options(thunder_edge,[],limits)
    pool=slice_pool(thunder_edge,cfg['excludedTiles']); values={i:stats([i]) for i in pool}
    legendary={i for i in pool if values[i]['legendaries']}
    lower=max(cfg['legendaryTotalMin'],7*cfg['legendaryMin'])
    upper=min(cfg['legendaryTotalMax'],7*cfg['legendaryMax'],len(legendary))
    deadline=_deadline if _deadline is not None else time.monotonic()+5
    while time.monotonic()<deadline:
        forced=[set() for _ in range(7)]; reserved=set()
        if cfg['connectedWormholes']:
            for w in ('alpha','beta'):
                ids=random.sample([i for i,t in pool.items() if w in t['wormhole']],3)
                for slot,i in zip(random.sample(range(7),3),ids):forced[slot].add(i);reserved.add(i)
        if any(sum(pool[i]['type']==color for i in f)>cap for f in forced for color,cap in (('blue',3),('red',2))):continue
        quotas=[max(cfg['legendaryMin'],len(f&legendary)) for f in forced]
        target=random.randint(lower,upper)
        if sum(quotas)>target or any(q>cfg['legendaryMax'] for q in quotas):continue
        for _ in range(target-sum(quotas)):
            choices=[n for n,q in enumerate(quotas) if q<cfg['legendaryMax']]
            if not choices:break
            quotas[random.choice(choices)]+=1
        used=set();result=[]
        for n in range(7):
            f=forced[n];available=set(pool)-used-reserved
            groups={(color,isleg):[i for i in available if pool[i]['type']==color and (i in legendary)==isleg] for color in ('blue','red') for isleg in (False,True)}
            nb=3-sum(pool[i]['type']=='blue' for i in f);nr=2-sum(pool[i]['type']=='red' for i in f);need=quotas[n]-len(f&legendary)
            allocations=[(lb,need-lb) for lb in range(nb+1) if 0<=need-lb<=nr and len(groups['blue',True])>=lb and len(groups['blue',False])>=nb-lb and len(groups['red',True])>=need-lb and len(groups['red',False])>=nr-(need-lb)]
            if not allocations:break
            found=False
            for attempt in range(200):
                if time.monotonic()>=deadline:break
                lb,lr=random.choice(allocations)
                ids=list(f)+random.sample(groups['blue',True],lb)+random.sample(groups['blue',False],nb-lb)+random.sample(groups['red',True],lr)+random.sample(groups['red',False],nr-lr)
                s=stats(ids)
                if not (cfg['resourcesMin']<=s['resources']<=cfg['resourcesMax'] and cfg['influenceMin']<=s['influence']<=cfg['influenceMax']):continue
                for _ in range(20):
                    random.shuffle(ids)
                    if (not cfg['noAdjacentAnomalies'] or (not any(TILES[t]['anomaly'] and distance(COORDS[i],(0,-3))==1 for i,t in enumerate(ids)) and all(compatible_anomalies(ids,prev['tiles']) for prev in result))) and not any(TILES[a]['anomaly'] and TILES[b]['anomaly'] and distance(COORDS[i],COORDS[j])==1 for i,a in enumerate(ids) for j,b in enumerate(ids) if i<j):
                        found=True;break
                if found:
                    result.append({'id':str(n),'name':f'Slice {chr(65+n)}','tiles':ids,'stats':s});used.update(ids);break
            if not found:break
        if len(result)==7 and (not cfg['connectedWormholes'] or wormholes_connected(result)):return result
    raise ValueError('No valid set was found within the generation budget. Widen the resource, influence or legendary ranges, or try generating again. No changes were saved.')

BALANCE_MODEL='overall-v1'
LEGENDARY_BONUS={'Primor':1.5,"Hope's End":1.75,'Faunus':1.5,'Garbozia':1.25,'Emelpar':1.5,'Tempesta':1.25,'Industrex':1.75}
TECH_COLORS={'biotic','warfare','propulsion','cybernetic'}
def strength(ids):
    """Transparent, faction-neutral draft heuristic; not a win-rate prediction."""
    import heapq
    parts={'economy':0.0,'nearHome':0.0,'planets':0.0,'traits':0.0,'technology':0.0,'legendary':0.0,'routes':0.0}
    trait_set=set();color_counts={};spend_r=spend_i=0.0
    for index,id in enumerate(ids):
        tile=TILES[id];coord=COORDS[index]
        adjacent=distance(coord,(0,-3))==1
        access=1.0 if adjacent else 0.65 if coord==(1,-2) else 0.85
        anomalies=set(tile['anomaly'])
        access*=0.0 if 'supernova' in anomalies else 0.85 if 'asteroid-field' in anomalies else 0.9 if 'nebula' in anomalies else 0.95 if 'gravity-rift' in anomalies else 1.0
        for p in tile['planets']:
            r,i=p['resources'],p['influence'];value=max(r,i)
            parts['economy']+=access*value
            parts['nearHome']+=(0.25*access*value if adjacent else 0)
            if r>i:spend_r+=access*r
            elif i>r:spend_i+=access*i
            else:spend_r+=access*r/2;spend_i+=access*i/2
            parts['planets']+=0.35*access*('space-station' not in p['specialty'])
            traits=p.get('trait') or [];traits=[traits] if isinstance(traits,str) else traits
            if access:trait_set.update(traits)
            for color in p['specialty']:
                if color in TECH_COLORS:color_counts[color]=color_counts.get(color,0)+access
            if 'legendary' in p['specialty']:parts['legendary']+=access*LEGENDARY_BONUS.get(p['name'],1.5)
    parts['traits']=0.4*len(trait_set)
    parts['technology']=sum(0.65*min(1,n)+0.2*max(0,n-1) for n in color_counts.values())
    # Cheapest route through the owned five-system geometry; external detours aren't assumed.
    nodes={(0,-3):None,(0,0):None,**{c:TILES[id] for c,id in zip(COORDS,ids)}}
    costs={(0,-3):0.0};queue=[(0.0,(0,-3))]
    while queue:
        cost,c=heapq.heappop(queue)
        if cost>costs[c]:continue
        for next_c,t in nodes.items():
            if distance(c,next_c)!=1 or (t and 'supernova' in t['anomaly']):continue
            a=set(t['anomaly']) if t else set()
            extra=0.5*('asteroid-field' in a)+0.35*('nebula' in a)+0.2*('gravity-rift' in a)
            new=cost+1+extra
            if new<costs.get(next_c,float('inf')):costs[next_c]=new;heapq.heappush(queue,(new,next_c))
    route=costs.get((0,0));parts['routes']=-2.5 if route is None else -0.6*max(0,route-3)
    return {'model':BALANCE_MODEL,'score':round(sum(parts.values()),3),'breakdown':{k:round(v,3) for k,v in parts.items()},'weightedSpend':{'resources':round(spend_r,2),'influence':round(spend_i,2)}}
def balance_quality(result):
    import math
    values=[strength(s['tiles'])['score'] for s in result];mean=sum(values)/len(values)
    span=max(values)-min(values);std=math.sqrt(sum((v-mean)**2 for v in values)/len(values))
    return (span+0.35*std)/max(mean,1)
def slices(thunder_edge=True,limits=None):
    import time
    _,cfg=normalize_options(thunder_edge,[],limits)
    if not cfg['balanceStrength']:return _generate_set(thunder_edge,cfg)
    deadline=time.monotonic()+5
    best=_generate_set(thunder_edge,cfg,deadline);quality=balance_quality(best);count=1
    while count<200 and time.monotonic()<deadline:
        try: candidate=_generate_set(thunder_edge,cfg,min(deadline,time.monotonic()+0.25))
        except ValueError:continue
        count+=1;q=balance_quality(candidate)
        if q<quality:best,quality=candidate,q
    for section in best:section['balance']=strength(section['tiles'])
    values=[section['balance']['score'] for section in best];mean=sum(values)/7
    best[0]['balanceSearch']={'model':BALANCE_MODEL,'candidatesCompared':count,'spreadPercent':round(100*(max(values)-min(values))/max(mean,1),1)}
    return best

def edited_slices(room, layouts):
    """Validate a complete map edit before mutating any persisted room state."""
    if not isinstance(layouts,list) or len(layouts)!=7 or any(not isinstance(row,list) or len(row)!=5 or any(not isinstance(i,str) for i in row) for row in layouts):
        raise ValueError('Provide seven slices with five tile IDs each.')
    _,cfg=normalize_options(thunder_enabled(room),room.get('settings',{}).get('bannedFactions'),room.get('settings',{}).get('sliceLimits'))
    pool=slice_pool(thunder_enabled(room),cfg['excludedTiles']);flat=[i for row in layouts for i in row]
    if any(i not in pool for i in flat):raise ValueError('Use only enabled, non-excluded ordinary systems; home and special tiles cannot be drafted.')
    if len(set(flat))!=35:raise ValueError('Each system tile can appear only once across the seven slices.')
    result=[]
    for n,ids in enumerate(layouts):
        name=room['slices'][n]['name'];v=stats(ids)
        if sum(pool[i]['type']=='blue' for i in ids)!=3:raise ValueError(f'{name}: use three blue and two red systems.')
        for key in ('resources','influence','legendary'):
            value=v['legendaries' if key=='legendary' else key]
            if not cfg[key+'Min']<=value<=cfg[key+'Max']:raise ValueError(f'{name}: {key} must be {cfg[key+"Min"]}–{cfg[key+"Max"]}; currently {value}.')
        if any(TILES[a]['anomaly'] and TILES[b]['anomaly'] and distance(COORDS[i],COORDS[j])==1 for i,a in enumerate(ids) for j,b in enumerate(ids) if i<j):raise ValueError(f'{name}: anomalies cannot touch inside a slice.')
        if cfg['noAdjacentAnomalies']:
            if any(TILES[t]['anomaly'] and distance(COORDS[i],(0,-3))==1 for i,t in enumerate(ids)):raise ValueError(f'{name}: an anomaly touches a home position.')
            if any(not compatible_anomalies(ids,previous['tiles']) for previous in result):raise ValueError(f'{name}: anomalies could touch across slice boundaries.')
        item={'id':room['slices'][n]['id'],'name':name,'tiles':list(ids),'stats':v}
        if cfg['balanceStrength']:item['balance']=strength(ids)
        result.append(item)
    total=sum(s['stats']['legendaries'] for s in result)
    if not cfg['legendaryTotalMin']<=total<=cfg['legendaryTotalMax']:raise ValueError(f'Total legendary planets must be {cfg["legendaryTotalMin"]}–{cfg["legendaryTotalMax"]}; currently {total}.')
    if cfg['connectedWormholes'] and not wormholes_connected(result):raise ValueError('Alpha and beta wormholes must each appear in at least three different slices.')
    return result

def digest(token): return hashlib.sha256(token.encode()).hexdigest()
def new_room(names,title,thunder_edge=True,banned=None,limits=None,order_mode='random',faction_mode='snake'):
    if faction_mode not in ('snake','free'):raise ValueError('Faction picking mode must be snake or free.')
    if order_mode not in ('random','manual'): raise ValueError('Draft order must be random or manual.')
    banned,limits=normalize_options(thunder_edge,banned,limits)
    if len(names)!=6 or any(not isinstance(n,str) or not n.strip() or len(n)>32 for n in names): raise ValueError('Enter six names, each 1–32 characters.')
    names=list(names)
    if order_mode=='random': random.shuffle(names)
    return {'title':str(title)[:80] or 'Six Cunts, One Throne','draftOrder':list(range(6)),'players':[{'name':n.strip(),'faction':None,'slice':None,'seat':None,'claim':None} for n in names], 'slices':slices(thunder_edge,limits),'settings':{'thundersEdge':bool(thunder_edge),'centerTile':'112' if thunder_edge else '18','orderMode':order_mode,'factionMode':faction_mode,'bannedFactions':banned,'sliceLimits':limits},'history':[],'started':False,'revision':0,'host':digest(secrets.token_urlsafe(32))}
def free_factions(room):return room.get('settings',{}).get('factionMode','snake')=='free'
def faction_phase(room):return free_factions(room) and any(p['faction'] is None for p in room['players'])
def turn(room):
    order=room.get('draftOrder',list(range(6)))
    if free_factions(room):
        if faction_phase(room):return None
        n=sum(p['kind']!='faction' for p in room['history']);sequence=order+list(reversed(order))
    else:
        n=len(room['history']);sequence=order+list(reversed(order))+order
    return sequence[n] if n<len(sequence) else None
def public(room):
    r=copy.deepcopy(room); r.pop('host');
    for section in r['slices']: section['stats']=stats(section['tiles'])
    for p in r['players']: p['claimed']=bool(p.pop('claim'))
    r['turn']=turn(room) if room['started'] else None
    r['phase']='lobby' if not room['started'] else 'factions' if faction_phase(room) else 'complete' if r['turn'] is None else 'draft'
    return r
def act(room,body,token):
    action=body.get('action'); key=digest(token); host=secrets.compare_digest(key,room['host'])
    concurrent_faction=room['started'] and faction_phase(room) and body.get('action')=='pick' and body.get('kind')=='faction'
    if not concurrent_faction and body.get('revision')!=room['revision']: raise ValueError('The draft changed. Refresh and try again.')
    if action=='claim':
        if any(p['claim']==key for p in room['players']): raise ValueError('You have already claimed a player.')
        index=int(body['player'])
        if index not in range(6): raise ValueError('Invalid player.')
        p=room['players'][index]
        if p['claim']: raise ValueError('This player is already claimed.')
        p['claim']=key
    elif action in ('start','undo','reroll','release','configure','order','editSlices'):
        if not host: raise PermissionError('Only the host can do that.')
        if action=='start':
            if room['started'] or not all(p['claim'] for p in room['players']): raise ValueError('All six players must claim their place first.')
            room['started']=True
        elif action=='undo':
            if not room['history']: raise ValueError('No pick to undo.')
            pick=room['history'].pop(); room['players'][pick['player']][pick['kind']]=None
        elif action=='release':
            index=int(body['player'])
            if index not in range(6): raise ValueError('Invalid player.')
            room['players'][index]['claim']=None
        elif action=='order':
            if room['started']: raise ValueError('Draft order is locked once the draft starts.')
            order=random.sample(range(6),6) if body.get('randomize') is True else body.get('order')
            if not isinstance(order,list) or len(order)!=6 or any(type(i) is not int for i in order) or sorted(order)!=list(range(6)): raise ValueError('Choose each player exactly once in the draft order.')
            room['draftOrder']=order
            room.setdefault('settings',{})['orderMode']='random' if body.get('randomize') is True else 'manual'
        elif action=='editSlices':
            if room['started']:raise ValueError('Map editing is locked once the draft starts.')
            result=edited_slices(room,body.get('tiles'))
            room['slices']=result
            room.setdefault('settings',{})['customSlices']=True
        elif action=='configure':
            if room['started']: raise ValueError('Setup is locked once the draft starts.')
            banned,cfg=normalize_options(thunder_enabled(room),body.get('bannedFactions',[]),body.get('sliceLimits'))
            mode=body.get('factionMode',room.get('settings',{}).get('factionMode','snake'))
            if mode not in ('snake','free'):raise ValueError('Faction picking mode must be snake or free.')
            generated=slices(thunder_enabled(room),cfg)
            room.setdefault('settings',{})['factionMode']=mode
            room.setdefault('settings',{})['bannedFactions']=banned
            room['settings']['sliceLimits']=cfg
            room['slices']=generated
            room['settings']['customSlices']=False
        elif action=='reroll':
            if room['started']: raise ValueError('Slices are locked once the draft starts.')
            room['slices']=slices(thunder_enabled(room),room.get('settings',{}).get('sliceLimits'))
            room['settings']['customSlices']=False
    elif action=='pick':
        current=turn(room)
        kind=body.get('kind'); value=str(body.get('value'))
        if not room['started']:raise ValueError('The draft is not active.')
        if faction_phase(room):
            if kind!='faction':raise ValueError('All six players must choose a faction before slice and speaker drafting begins.')
            current=next((i for i,p in enumerate(room['players']) if p['claim']==key),None)
            if current is None:raise PermissionError('Claim your player before picking a faction.')
        elif current is None:raise ValueError('The draft is not active.')
        elif free_factions(room) and kind=='faction':raise ValueError('Faction picking is complete.')
        p=room['players'][current]
        if p['claim']!=key: raise PermissionError('It is not your turn.')
        allowed={'faction':[f['id'] for f in factions_for(room)], 'slice':[s['id'] for s in room['slices']], 'seat':[str(i) for i in range(1,7)]}
        if kind not in allowed or value not in allowed[kind]: raise ValueError('Invalid choice.')
        if p[kind] is not None or any(x[kind]==value for x in room['players']): raise ValueError('That choice is already taken, or you already picked that category.')
        p[kind]=value; room['history'].append({'player':current,'kind':kind,'value':value})
    else: raise ValueError('Unknown action.')
    room['revision']+=1
