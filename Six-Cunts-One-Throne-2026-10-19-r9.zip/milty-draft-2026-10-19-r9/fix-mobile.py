"""Apply the mobile rendering hotfix in-place without changing saved rooms."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
path=root/'data/tiles.json'
tiles=json.loads(path.read_text())
for tile in tiles.values():
    for key in ('anomaly','wormhole'):
        value=tile.get(key)
        tile[key]=value if isinstance(value,list) else [] if value is None else [value]
path.write_text(json.dumps(tiles,indent=2)+'\n')
path=root/'static/app.js'
source=path.read_text()
source=source.replace('viewBox="-50 -195 200 200"','viewBox="-130 -201 200 193"')
path.write_text(source)
print('Fixed slice bounds and normalised system data. Saved rooms are unchanged.')
