const $=id=>document.getElementById(id), esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let room, data, code=new URLSearchParams(location.search).get('room'), pending;
const keyName=()=>`ti4:${code}`;
let credentials=code?JSON.parse(localStorage.getItem(keyName())||'{}'):{};
const hash=new URLSearchParams(location.hash.slice(1));if(code&&hash.has('host')){credentials.host=hash.get('host');localStorage.setItem(keyName(),JSON.stringify(credentials));history.replaceState(null,'',location.pathname+location.search)}
let playerToken=credentials.player||crypto.randomUUID()+crypto.randomUUID();
function notice(t){$('notice').textContent=t;$('notice').style.display='block';setTimeout(()=>$('notice').style.display='none',7000)}
async function api(path,body,host=false){let r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json',Authorization:`Bearer ${host?credentials.host:playerToken}`},body:body?JSON.stringify(body):undefined});let v=await r.json();if(!r.ok)throw Error(v.error||'Request failed');return v}
function save(){localStorage.setItem(keyName(),JSON.stringify(credentials))}
function teEnabled(){return !!room?.settings?.thundersEdge}
function availableFactions(){return data.factions.filter(f=>(teEnabled()||f.expansion!=='te')&&!(room.settings?.bannedFactions||[]).includes(f.id))}
function label(kind,id){return kind==='faction'?data.factions.find(f=>f.id===id)?.name:kind==='slice'?room.slices.find(s=>s.id===id)?.name:`Seat ${id}${id==='1'?' · Speaker':''}`}
function mine(){return Number.isInteger(credentials.index)?room.players[credentials.index]:null}
function owner(kind,id){return room.players.find(p=>p[kind]===id)}
function can(kind,id){let me=mine();return room.started&&room.turn===credentials.index&&me&&!me[kind]&&!owner(kind,id)}
async function action(body,host=false){try{room=await api(`/api/rooms/${code}`,{...body,revision:room.revision},host);render()}catch(e){notice(e.message);await refresh()}}
function pick(kind,value){if(!can(kind,value))return;pending={action:'pick',kind,value};$('confirm-text').textContent=`${label(kind,value)}. This uses your ${kind==='seat'?'speaker order':kind} pick.`;$('confirm').showModal()}
$('cancel-pick').onclick=()=>$('confirm').close();$('commit').onclick=async()=>{$('confirm').close();await action(pending)};
function rotate(q,r,n){for(let i=0;i<n;i++)[q,r]=[-r,q+r];return[q,r]}
function tileArt(id){return data.tileArt?.[String(id)]||null}
function hex(q,r,tile,home=false,caption=''){
 let x=52.5*q,y=35*Math.sqrt(3)*(r+q/2);
 let points=Array.from({length:6},(_,i)=>{let a=Math.PI/180*60*i;return `${x+35*Math.cos(a)},${y+35*Math.sin(a)}`}).join(' ');
 let t=data.tiles[tile],art=tileArt(tile),name=t?t.planets.map(p=>p.name).join(' / ')||t.anomaly.join(' / ')||'Empty space':home?'Home system':'Unpicked system';
 let attrs=t?`class="system-hex" data-tile="${esc(tile)}" role="button" tabindex="0" aria-label="Inspect tile ${esc(tile)}: ${esc(name)}"`:'';
 return `<g ${attrs}><title>${esc(t?'Tile '+tile+' · '+name:caption||name)}</title>${art?`<image href="${esc(art)}" x="${x-35}" y="${y-35*Math.sqrt(3)/2}" width="70" height="${35*Math.sqrt(3)}" preserveAspectRatio="xMidYMid meet"/>`:`<polygon class="${home?'home':t?.type==='red'?'red':''}" points="${points}"/><text x="${x}" y="${y-4}" text-anchor="middle">${esc(home?'HOME':tile||'?')}</text><text x="${x}" y="${y+9}" text-anchor="middle">${esc(home?caption:'Unpicked')}</text>`}${t?`<polygon class="hex-hit" points="${points}"/>`:''}${home&&art&&caption?`<text class="home-caption" x="${x}" y="${y+24}" text-anchor="middle">${esc(caption)}</text>`:''}</g>`
}
const coords=[[0,-1],[0,-2],[1,-2],[1,-3],[-1,-2]];
function sliceSvg(s){return `<svg class="slice-art" viewBox="-98 20 196 204" role="group" aria-label="${esc(s.name)} · tap a system to inspect it">${s.tiles.map((t,i)=>hex(...rotate(...coords[i],3),t)).join('')}${hex(...rotate(0,-3,3),null,true,'HOME')}</svg><div class="tile-strip" aria-label="Inspect systems">${s.tiles.map(t=>`<button data-tile="${t}" title="Inspect tile ${t}">#${t}</button>`).join('')}</div>`}
function render(){
 $('expansion-summary').textContent=(teEnabled()?'Thunder’s Edge enabled · Legendary Mecatol Rex':'Base + PoK + Keleres')+` · ${availableFactions().length} available factions`;$('setup').hidden=true;$('draft').hidden=false;$('room-title').textContent=room.title;
 $('turn').textContent=!room.started?'Waiting for the six contenders to claim their places.':room.turn===null?'The draft is complete. The galaxy awaits.':`${room.players[room.turn].name} is on the clock · Pick ${room.history.length+1} of 18 · No time limit`;
 $('players').innerHTML=room.players.map((p,i)=>({p,i})).sort((a,b)=>(room.draftOrder||[0,1,2,3,4,5]).indexOf(a.i)-(room.draftOrder||[0,1,2,3,4,5]).indexOf(b.i)).map(({p,i})=>`<div class="player ${room.turn===i?'current':''}"><strong>${(room.draftOrder||[0,1,2,3,4,5]).indexOf(i)+1}. ${esc(p.name)}${credentials.index===i?' · You':''}</strong><p>${['faction','slice','seat'].map(k=>p[k]?esc(label(k,p[k])):'—').join('<br>')}</p>${!p.claimed?`<button data-claim="${i}">Claim ${esc(p.name)}</button>`:'<span class="muted">Joined</span>'}${credentials.host&&p.claimed?` <button data-release="${i}">Release access</button>`:''}</div>`).join('');
 document.querySelectorAll('[data-claim]').forEach(b=>{b.disabled=!!mine()?.claimed;b.onclick=async()=>{let i=Number(b.dataset.claim);try{room=await api(`/api/rooms/${code}`,{action:'claim',player:i,revision:room.revision});credentials.player=playerToken;credentials.index=i;save();render()}catch(e){notice(e.message);refresh()}}});
 document.querySelectorAll('[data-release]').forEach(b=>b.onclick=()=>{if(confirm('Release this player’s access? They can reclaim their name with a new device.'))action({action:'release',player:Number(b.dataset.release)},true)});
 $('slices').innerHTML='<div class="slice-grid">'+room.slices.map(s=>`<article class="panel slice ${owner('slice',s.id)?'taken':''}"><div class="slice-head"><h2>${s.name}</h2><span class="eyebrow">${owner('slice',s.id)?esc(owner('slice',s.id).name):'AVAILABLE'}</span></div>${sliceSvg(s)}${strengthPanel(s)}<div class="stats"><div><strong>${s.stats.resources}</strong> <span>RES</span></div><div><strong>${s.stats.influence}</strong> <span>INF</span></div><div><strong>${s.stats.effective}</strong> <span>EFF</span></div><div><strong>${s.stats.skips}</strong> <span>TECH ICONS</span></div></div><p class="muted">${s.stats.legendaries||0} legendary · ${s.stats.stations||0} space stations</p><button data-pick="slice" data-value="${s.id}" ${can('slice',s.id)?'':'disabled'}>Draft ${s.name}</button></article>`).join('')+'</div><p class="muted">Each slice has three blue and two red systems. EFF sums each planet’s better resource/influence value; totals cannot all be spent together. See Draft rules for the selected anomaly restrictions.</p>';
 renderFactions();$('seats').innerHTML=Array.from({length:6},(_,i)=>{let id=String(i+1);return `<button class="seat" data-pick="seat" data-value="${id}" ${can('seat',id)?'':'disabled'}><strong>${id}</strong>${i===0?'Speaker':'Clockwise from speaker'}<br>${esc(owner('seat',id)?.name||'Available')}</button>`}).join('');
 $('host').hidden=!credentials.host;$('start').disabled=room.started||!room.players.every(p=>p.claimed);$('reroll').disabled=room.started;$('edit-map').disabled=room.started;$('undo').disabled=!room.history.length;
 $('log').innerHTML=room.history.map(p=>`<li>${esc(room.players[p.player].name)} → ${esc(label(p.kind,p.value))}</li>`).join('')||'<li>No picks yet.</li>';
 bindPicks();renderMap();renderSystems();renderRules();renderOrder();
}
function renderFactions(){let q=$('search').value.toLowerCase();$('faction-list').innerHTML=availableFactions().filter(f=>f.name.toLowerCase().includes(q)).map(f=>`<button class="faction" data-pick="faction" data-value="${f.id}" ${can('faction',f.id)?'':'disabled'}><small>${owner('faction',f.id)?esc(owner('faction',f.id).name):f.expansion==='te'?'THUNDER’S EDGE':f.id==='keleres'?'CODEX III':f.expansion==='pok'?'PROPHECY OF KINGS':'BASE GAME'}</small>${esc(f.name)}</button>`).join('');bindPicks()}
function bindPicks(){document.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>pick(b.dataset.pick,b.dataset.value))}
function renderMap(){let parts=[hex(0,0,teEnabled()?'112':'18')],cells=[];for(let n=0;n<6;n++){let p=room.players.find(p=>p.seat===String(n+1)),s=room.slices.find(s=>s.id===p?.slice);coords.forEach((c,i)=>{let cr=rotate(...c,n),id=s?.tiles[i];parts.push(hex(...cr,id));if(id)cells.push({c:cr,id})});let f=data.factions.find(f=>f.id===p?.faction);parts.push(hex(...rotate(0,-3,n),f?.home||null,true,p?p.name:`Seat ${n+1}`));} $('galaxy').innerHTML=`<svg viewBox="-210 -230 420 460" aria-label="Six player galaxy map" role="img">${parts.join('')}</svg>`;let warnings=[];for(let i=0;i<cells.length;i++)for(let j=i+1;j<cells.length;j++){let a=cells[i],b=cells[j],q=a.c[0]-b.c[0],r=a.c[1]-b.c[1];if(Math.max(Math.abs(q),Math.abs(r),Math.abs(q+r))===1&&data.tiles[a.id].anomaly.length&&data.tiles[b.id].anomaly.length)warnings.push(`${a.id} / ${b.id}`)}$('map-warning').textContent=warnings.length?'Adjacent anomalies across slices: '+warnings.join(', ')+'. Agree any tile swaps before setup.':'Home systems are labelled by player; use the home tile for their chosen faction. Keleres selects an eligible unused faction’s home system after the draft. See Systems & setup for Thunder’s Edge components.'}
async function refresh(){try{let r=await api(`/api/rooms/${code}`);if(!room||r.revision!==room.revision){room=r;render()}$('connection').textContent='CONNECTED · ASYNC PICKS'}catch(e){$('connection').textContent='OFFLINE · RETRYING';if(!room)notice(e.message)}}
async function copy(t){try{await navigator.clipboard.writeText(t);notice('Link copied.')}catch{prompt('Copy this link:',t)}}
$('invite').onclick=()=>copy(`${location.origin}/?room=${code}`);$('host-link').onclick=()=>copy(`${location.origin}/?room=${code}#host=${credentials.host}`);
$('start').onclick=()=>action({action:'start'},true);$('reroll').onclick=()=>{if(confirm('Replace all seven slices?'))action({action:'reroll'},true)};$('undo').onclick=()=>{if(confirm('Undo the last pick?'))action({action:'undo'},true)};
$('export').onclick=()=>{let payload={...room,factions:data.factions,notes:'Seat 1 is speaker. Keleres home variant is chosen after drafting. Crimson uses gate 94 and off-board home 118; Firmament starts on 96A.',thundersEdge:teEnabled()?data.thundersEdge:null,map:room.players.filter(p=>p.seat).map(p=>({player:p.name,seat:p.seat,faction:label('faction',p.faction),home:data.factions.find(f=>f.id===p.faction)?.home,additionalHome:data.factions.find(f=>f.id===p.faction)?.additionalHome,reverseHome:data.factions.find(f=>f.id===p.faction)?.reverseHome,tiles:room.slices.find(s=>s.id===p.slice)?.tiles,relativeCoordinates:coords}))};let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));a.download='ti4-draft.json';a.click();URL.revokeObjectURL(a.href)};
$('search').oninput=renderFactions;document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(t=>t.hidden=t.id!==b.dataset.tab);document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x===b))});
['Cameron','Elliot','Martin','Nathan','Ryan','George'].forEach((n,i)=>$('names').insertAdjacentHTML('beforeend',`<label>Contender ${i+1}<input class="player-name" value="${n}" maxlength="32"></label>`));
$('create').onclick=async()=>{$('create').disabled=true;try{let result=await api('/api/rooms',{title:$('title').value,orderMode:$('order-mode').value,thundersEdge:$('thunders-edge').checked,...readOptions('setup'),names:[...document.querySelectorAll('.player-name')].map(n=>n.value)});code=result.code;credentials={host:result.token};save();room=result.room;history.replaceState(null,'',`?room=${code}`);render();setInterval(()=>{if(!document.hidden)refresh()},15000)}catch(e){notice(e.message)}finally{$('create').disabled=false}};
(async()=>{try{data=await api('/api/data');renderOptions('setup',{},$('thunders-edge').checked);if(code){await refresh();setInterval(()=>{if(!document.hidden)refresh()},15000)}}catch(e){notice(e.message)}})();

document.addEventListener('visibilitychange',()=>{if(!document.hidden&&code)refresh()});

function renderSystems(){
 const source='https://twilight-imperium.fandom.com/wiki/Thunder%27s_Edge';
 $('te-setup').innerHTML=teEnabled()?`<div class="eyebrow">THUNDER’S EDGE · DRAFT SETUP</div><h2>A larger galaxy</h2><p>${availableFactions().length} available factions after setup bans. The Firmament and Obsidian share one slot: start as the Firmament on 96A; 96B is the reverse home system.</p><p>Crimson Rebellion places The Sorrow (94) in its home position and Ahk Creuxx (118) off board. Use legendary Mecatol Rex (112) at the center, replacing 18.</p><p>The Fracture (125–127) and the Thunder’s Edge expedition planet begin outside the draft galaxy and enter through their game rules. Hyperlanes 119–124 are not used by this six-player map.</p><p class="muted">Draft support covers factions, systems, map and setup references. Resolve breakthroughs, expeditions, Fracture entry, neutral forces and any optional Galactic Events at the table. Twilight’s Fall is a separate mode and is not drafted here.</p><details><summary>Special component reference</summary><p>${data.thundersEdge.fracture.map(t=>'Tile '+t.tile+': '+t.systems.map(s=>s.egress?'Egress':s.empty?'Empty space':s.planets.map(p=>esc(p.name)+' '+p.resources+'/'+p.influence).join(' + ')).join(' / ')).join('<br>')}</p><p>Thunder’s Edge planet: 5/1 · Legendary · Expedition component.<br>Avernus: 2/0 · Legendary · Muaat breakthrough component.</p></details><p><a href="${source}" target="_blank" rel="noopener">Thunder’s Edge wiki ↗</a> · <a href="https://twilight-imperium.fandom.com/wiki/Tiles_List" target="_blank" rel="noopener">Wiki tile list ↗</a></p>`:'<h2>Base + PoK + Keleres</h2><p>Thunder’s Edge is disabled for this room. Its factions and tiles are excluded. Create a new room with the expansion enabled to use them.</p>';
 let q=$('system-search').value.toLowerCase();let rows=Object.entries(data.tiles).filter(([id,t])=>(teEnabled()||t.expansion!=='te')&&(id+' '+JSON.stringify(t)).toLowerCase().includes(q));
 $('system-list').innerHTML=rows.map(([id,t])=>`<article class="panel system">${tileArt(id)?`<button class="catalogue-art" data-tile="${id}" aria-label="Inspect tile ${id}"><img src="${tileArt(id)}" alt="System tile ${id}" loading="lazy"></button>`:''}<div class="eyebrow">${esc(t.expansion==='te'?'THUNDER’S EDGE':t.expansion==='pok'?'PROPHECY OF KINGS':'BASE GAME')} · ${esc(id)} · ${esc(t.type)}</div><h3>${esc(t.faction||t.planets.map(p=>p.name).join(' / ')||t.anomaly.join(' / ')||'Empty space')}</h3>${t.planets.map(p=>`<p>${esc(p.name)} <strong>${p.resources}/${p.influence}</strong> · ${esc(Array.isArray(p.trait)?p.trait.join(' + '):p.trait||'No trait')} · ${esc(p.specialty.join(', ')||'No specialty')}</p>`).join('')}<p class="muted">${esc([...t.anomaly,...t.wormhole.map(w=>w+' wormhole')].join(' · '))}${t.special?' · Special component; excluded from slices':t.type==='green'?' · Home/gate; excluded from slices':' · Eligible for generated slices'}</p></article>`).join('');
}
$('system-search').oninput=renderSystems;

const limitFields=[['resourcesMin','Resources · minimum'],['resourcesMax','Resources · maximum'],['influenceMin','Influence · minimum'],['influenceMax','Influence · maximum'],['legendaryMin','Legendary planets per slice · minimum'],['legendaryMax','Legendary planets per slice · maximum'],['legendaryTotalMin','Legendary planets in all 7 slices · minimum'],['legendaryTotalMax','Legendary planets in all 7 slices · maximum']];
function renderOptions(prefix,settings,te){
 let cfg={...data.defaultLimits,...settings.sliceLimits},banned=settings.bannedFactions||[];
 let factions=data.factions.filter(f=>te||f.expansion!=='te');
 let systems=Object.entries(data.tiles).filter(([id,t])=>['blue','red'].includes(t.type)&&!t.special&&(te||t.expansion!=='te')).sort((a,b)=>Number(b[1].planets.some(p=>p.specialty.includes('legendary')))-Number(a[1].planets.some(p=>p.specialty.includes('legendary')))||Number(a[0])-Number(b[0]));
 $(prefix+'-options').innerHTML=`<h3>Slice limits</h3><label class="check"><input id="${prefix}-balanceStrength" type="checkbox" ${cfg.balanceStrength?'checked':''}> Balance overall slice strength (optional)</label><p class="muted">Compare up to 200 valid sets within 5 seconds and keep the closest estimated strengths. Different resource/influence economies are allowed. Uses economy without double-counting, home adjacency, contested systems, planet traits, technology specialties, legendaries and routes. All your limits still apply.</p><p class="muted">Resources and influence are separate printed totals for each five-system slice. Limits are inclusive. For an exact legendary total, set its minimum and maximum to the same number.</p><div class="limit-grid">${limitFields.map(([key,label])=>`<label>${label}<input id="${prefix}-${key}" type="number" min="0" max="${key.startsWith('legendary')&&!key.startsWith('legendaryTotal')?5:100}" step="1" required value="${esc(cfg[key])}"></label>`).join('')}</div><label class="check"><input id="${prefix}-connectedWormholes" type="checkbox" ${cfg.connectedWormholes?'checked':''}> Guarantee connected alpha and beta wormholes</label><p class="muted">When enabled, each type appears in at least 3 different slices, so matching wormholes survive whichever slice is left unpicked. Total legendary limits cover all 7 offered slices, not exactly the final 6.</p><label class="check"><input id="${prefix}-noAdjacentAnomalies" type="checkbox" ${cfg.noAdjacentAnomalies?'checked':''}> No adjacent anomalies anywhere in the galaxy</label><p class="muted">Guarantees no touching anomalies across slice borders, for every seat arrangement. Also keeps them away from home systems, including anomalous faction homes. Generation may need wider ranges.</p><details class="system-exclusions"><summary>Exclude planet systems · ${(cfg.excludedTiles||[]).length} excluded</summary><p class="muted">Tick systems to exclude from every generated slice. A planet exclusion removes its entire tile. Legendary systems are listed first; Mecatol and faction homes cannot be excluded here.</p><input id="${prefix}-exclusion-search" placeholder="Find Industrex, a planet, anomaly or tile number…" aria-label="Search systems to exclude"><div class="ban-grid exclusion-list">${systems.map(([id,t])=>`<label class="check" data-exclusion-label="${prefix}" data-search="${esc((id+' '+t.planets.map(p=>p.name).join(' ')+' '+t.anomaly.join(' ')).toLowerCase())}"><input type="checkbox" data-exclude="${prefix}" value="${id}" ${(cfg.excludedTiles||[]).includes(id)?'checked':''}>${esc(t.planets.map(p=>p.name).join(' / ')||t.anomaly.join(' / ')||'Empty space')} · #${id}${t.planets.some(p=>p.specialty.includes('legendary'))?' ★':''}</label>`).join('')}</div></details><details><summary>Ban factions · ${banned.length} banned</summary><p class="muted">Tick factions to ban. All other enabled factions remain available; leave at least six.</p><div class="ban-grid">${factions.map(f=>`<label class="check"><input type="checkbox" data-ban="${prefix}" value="${esc(f.id)}" ${banned.includes(f.id)?'checked':''}>${esc(f.name)}</label>`).join('')}</div></details>`;
 $(prefix+'-exclusion-search').oninput=e=>{let q=e.target.value.toLowerCase();document.querySelectorAll(`[data-exclusion-label="${prefix}"]`).forEach(l=>l.hidden=!l.dataset.search.includes(q))};
}
function readOptions(prefix){
 let sliceLimits={};for(let [key] of limitFields){let input=$(prefix+'-'+key);if(!input.checkValidity())throw Error('Enter valid whole-number slice limits.');sliceLimits[key]=Number(input.value)}
 sliceLimits.balanceStrength=$(prefix+'-balanceStrength').checked;
 sliceLimits.excludedTiles=[...document.querySelectorAll(`[data-exclude="${prefix}"]:checked`)].map(i=>i.value);
 sliceLimits.noAdjacentAnomalies=$(prefix+'-noAdjacentAnomalies').checked;
 sliceLimits.connectedWormholes=$(prefix+'-connectedWormholes').checked;
 return {sliceLimits,bannedFactions:[...document.querySelectorAll(`[data-ban="${prefix}"]:checked`)].map(i=>i.value)};
}
function renderRules(){
 let settings=room.settings||{},c={...data.defaultLimits,...settings.sliceLimits};
 $('rules-summary').textContent=(settings.sliceLimits?'':'Legacy slices: these limits apply on the next regeneration. ')+`Each slice: ${c.resourcesMin}–${c.resourcesMax} resources · ${c.influenceMin}–${c.influenceMax} influence · ${c.legendaryMin}–${c.legendaryMax} legendary planets. All 7 slices: ${c.legendaryTotalMin}–${c.legendaryTotalMax} legendary planets. Matching wormholes: ${c.connectedWormholes?'guaranteed, including after any one slice is omitted':'not required'}. Anomalies: ${c.noAdjacentAnomalies?'no adjacent anomalies anywhere, including home boundaries':'no adjacent anomalies inside each slice; cross-slice adjacency is possible'}.`;
 let balance=document.createElement('p');balance.className='muted';let search=room.slices[0]?.balanceSearch;balance.textContent=c.balanceStrength?(search?`Overall strength balancing ON · ${search.candidatesCompared} valid sets compared · score spread ${search.spreadPercent}% of the average · model ${search.model}`:(settings.customSlices?'Custom slices · strength scores recalculated after editing; no automatic equalisation.':'Overall strength balancing ON for the next regeneration.')):'Overall strength balancing OFF · ordinary random generation.';$('rules-summary').appendChild(balance);
 let excluded=c.excludedTiles||[];let ex=document.createElement('p');ex.className='muted';ex.textContent=excluded.length?'Excluded systems: '+excluded.map(id=>(data.tiles[id]?.planets.map(p=>p.name).join(' / ')||'System')+' #'+id).join(', '):'No planet systems excluded.';$('rules-summary').appendChild(ex);
 let bans=settings.bannedFactions||[];let p=document.createElement('p');p.className='muted';p.textContent=bans.length?'Banned: '+bans.map(id=>data.factions.find(f=>f.id===id)?.name||id).join(', '):'No faction bans. All enabled factions are available.';$('rules-summary').appendChild(p);
 $('lobby-settings').hidden=!credentials.host||room.started;
 // Avoid resetting unsaved setup edits when other players claim their names.
 let signature=JSON.stringify(settings);
 if($('lobby-options').dataset.settings!==signature){renderOptions('lobby',settings,teEnabled());$('lobby-options').dataset.settings=signature}
}
$('thunders-edge').onchange=()=>{try{let current=readOptions('setup');current.bannedFactions=current.bannedFactions.filter(id=>data.factions.some(f=>f.id===id&&($('thunders-edge').checked||f.expansion!=='te')));current.sliceLimits.excludedTiles=current.sliceLimits.excludedTiles.filter(id=>$('thunders-edge').checked||data.tiles[id].expansion!=='te');renderOptions('setup',current,$('thunders-edge').checked)}catch(e){notice(e.message)}};
$('apply-settings').onclick=async()=>{try{let options=readOptions('lobby');$('apply-settings').disabled=true;await action({action:'configure',...options},true)}catch(e){notice(e.message)}finally{$('apply-settings').disabled=false}};

function renderOrder(){
 $('order-editor').hidden=room.started;
 let order=room.draftOrder||[0,1,2,3,4,5],signature=JSON.stringify(order);
 if($('order-fields').dataset.order===signature)return;
 $('order-fields').innerHTML=order.map((index,n)=>`<label>Pick position ${n+1}<select data-order-position="${n}">${room.players.map((p,i)=>`<option value="${i}" ${i===index?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label>`).join('');
 $('order-fields').dataset.order=signature;
}
$('save-order').onclick=()=>action({action:'order',order:[...document.querySelectorAll('[data-order-position]')].map(s=>Number(s.value))},true);
$('shuffle-order').onclick=()=>action({action:'order',randomize:true},true);

function inspectTile(id){
 let t=data.tiles[id];if(!t)return;
 $('tile-title').textContent=`Tile ${id} · ${t.faction||t.planets.map(p=>p.name).join(' / ')||t.anomaly.join(' / ')||'Empty space'}`;
 let art=tileArt(id);
 $('tile-detail-body').innerHTML=`${art?`<img class="tile-large" src="${esc(art)}" alt="System tile ${esc(id)}">`:'<p class="muted">Artwork is unavailable for this special reverse side.</p>'}<div class="planet-details">${t.planets.map(p=>`<section><h3>${esc(p.name)}</h3><div class="planet-values"><span>${p.resources} resources</span><span>${p.influence} influence</span></div><p>${esc(Array.isArray(p.trait)?p.trait.join(' + '):p.trait||'No planet trait')}</p><p>${esc(p.specialty.map(s=>({biotic:'Green technology',warfare:'Red technology',propulsion:'Blue technology',cybernetic:'Yellow technology',legendary:'Legendary planet','space-station':'Space station'}[s]||s)).join(' · ')||'No technology specialty')}</p></section>`).join('')||'<p>No planets in this system.</p>'}<p class="muted">${esc([...t.anomaly,...t.wormhole.map(w=>w+' wormhole')].join(' · ')||'No anomaly or wormhole')}</p></div>`;
 $('tile-detail').showModal();
}
$('close-tile').onclick=()=>$('tile-detail').close();
$('tile-detail').addEventListener('click',e=>{if(e.target===$('tile-detail'))$('tile-detail').close()});
document.addEventListener('click',e=>{let el=e.target.closest('[data-tile]');if(el)inspectTile(el.dataset.tile)});
document.addEventListener('keydown',e=>{let el=e.target.closest('[data-tile]');if(el&&(e.key==='Enter'||e.key===' ')){e.preventDefault();inspectTile(el.dataset.tile)}});

function strengthPanel(s){
 if(!room.settings?.sliceLimits?.balanceStrength||!s.balance)return '';
 let names={economy:'Accessible economy',nearHome:'Home-adjacent bonus',planets:'Planet access',traits:'Trait diversity',technology:'Technology specialties',legendary:'Legendary value',routes:'Route adjustment'};
 return `<details class="strength-panel"><summary><span>Estimated strength</span><strong>${Number(s.balance.score).toFixed(1)}</strong></summary><dl>${Object.entries(s.balance.breakdown).map(([k,v])=>`<div><dt>${esc(names[k]||k)}</dt><dd>${Number(v).toFixed(2)}</dd></div>`).join('')}</dl><p class="muted">Faction-neutral heuristic. It compares potential, not guaranteed income or win rates. Equidistant value is discounted. Model ${esc(s.balance.model)}.</p></details>`;
}

let mapEdit=null;
const editorPositions=['Towards Mecatol','Home neighbour · middle','Equidistant','Home neighbour · side 1','Home neighbour · side 2'];
function editorStats(ids){let p=ids.flatMap(id=>data.tiles[id].planets);return {resources:p.reduce((a,p)=>a+p.resources,0),influence:p.reduce((a,p)=>a+p.influence,0),legendaries:p.filter(p=>p.specialty.includes('legendary')).length}}
function editorTileName(id){let t=data.tiles[id];return '#'+id+' · '+(t.planets.map(p=>p.name).join(' / ')||t.anomaly.join(' / ')||'Empty space')}
function editorMessage(text){$('editor-status').textContent=text}
function renderEditor(){
 if(!mapEdit)return;
 let cfg={...data.defaultLimits,...room.settings?.sliceLimits};
 $('editor-slices').innerHTML=mapEdit.tiles.map((ids,n)=>{let v=editorStats(ids),s={...room.slices[n],tiles:ids};let blue=ids.filter(id=>data.tiles[id].type==='blue').length;let valid=blue===3&&v.resources>=cfg.resourcesMin&&v.resources<=cfg.resourcesMax&&v.influence>=cfg.influenceMin&&v.influence<=cfg.influenceMax&&v.legendaries>=cfg.legendaryMin&&v.legendaries<=cfg.legendaryMax;
 return `<section class="editor-slice"><h3>${esc(s.name)}</h3><div class="editor-preview">${sliceSvg(s)}</div><p class="${valid?'muted':'editor-warning'}">${v.resources} RES · ${v.influence} INF · ${v.legendaries} legendary · ${blue} blue / ${5-blue} red${valid?'':' · Outside slice limits'}</p><div class="editor-slots">${ids.map((id,i)=>`<button data-edit-slot="${n},${i}" class="${mapEdit.selected?.[0]===n&&mapEdit.selected?.[1]===i?'selected':''}" aria-pressed="${mapEdit.selected?.[0]===n&&mapEdit.selected?.[1]===i}"><small>${editorPositions[i]}</small>${esc(editorTileName(id))}</button>`).join('')}</div></section>`}).join('');
 document.querySelectorAll('[data-edit-slot]').forEach(b=>b.onclick=()=>editorSlot(...b.dataset.editSlot.split(',').map(Number)));
 // The preview hexes select positions instead of opening the inspector.
 document.querySelectorAll('.editor-preview').forEach((preview,n)=>preview.querySelectorAll('[data-tile]').forEach(el=>{let i=mapEdit.tiles[n].indexOf(el.dataset.tile);el.removeAttribute('data-tile');el.setAttribute('aria-label','Edit '+editorPositions[i]);el.onclick=()=>editorSlot(n,i);el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();editorSlot(n,i)}}}));
 $('editor-undo').disabled=!mapEdit.undo.length;
 renderEditorPool();
}
function editorSlot(n,i){
 if(!mapEdit.selected){mapEdit.selected=[n,i];editorMessage('Selected '+room.slices[n].name+' · '+editorPositions[i]+'. Choose another position to swap, or an unused system.');renderEditor();return}
 let [a,b]=mapEdit.selected;
 if(a===n&&b===i){mapEdit.selected=null;renderEditor();return}
 mapEdit.undo.push(mapEdit.tiles.map(row=>[...row]));
 [mapEdit.tiles[a][b],mapEdit.tiles[n][i]]=[mapEdit.tiles[n][i],mapEdit.tiles[a][b]];mapEdit.selected=null;
 editorMessage('Systems swapped. Save to validate every setup limit.');renderEditor();
}
function renderEditorPool(){
 if(!mapEdit)return;let used=new Set(mapEdit.tiles.flat()),q=$('editor-search').value.toLowerCase(),excluded=room.settings?.sliceLimits?.excludedTiles||[];
 let pool=Object.entries(data.tiles).filter(([id,t])=>['blue','red'].includes(t.type)&&!t.special&&(teEnabled()||t.expansion!=='te')&&!excluded.includes(id)&&!used.has(id)&&(id+' '+JSON.stringify(t)).toLowerCase().includes(q));
 $('editor-pool').innerHTML=pool.map(([id,t])=>`<button class="editor-replacement" data-replace="${id}" ${mapEdit.selected?'':'disabled'}>${tileArt(id)?`<img src="${esc(tileArt(id))}" alt="" loading="lazy">`:''}<span>${esc(editorTileName(id))}<small>${t.type.toUpperCase()} · ${editorStats([id]).resources} RES / ${editorStats([id]).influence} INF</small></span></button>`).join('')||'<p class="muted">No matching unused systems.</p>';
 document.querySelectorAll('[data-replace]').forEach(b=>b.onclick=()=>{if(!mapEdit.selected)return;mapEdit.undo.push(mapEdit.tiles.map(row=>[...row]));let [n,i]=mapEdit.selected;mapEdit.tiles[n][i]=b.dataset.replace;mapEdit.selected=null;editorMessage('System replaced. Save to validate every setup limit.');renderEditor()});
}
$('edit-map').onclick=()=>{mapEdit={tiles:room.slices.map(s=>[...s.tiles]),original:room.slices.map(s=>[...s.tiles]),revision:room.revision,undo:[],selected:null};$('editor-search').value='';editorMessage('Select a position to begin.');renderEditor();$('map-editor').showModal()};
function closeEditor(){if(mapEdit&&JSON.stringify(mapEdit.tiles)!==JSON.stringify(mapEdit.original)&&!confirm('Discard your unsaved map edits?'))return;$('map-editor').close();mapEdit=null}
$('close-editor').onclick=closeEditor;
$('map-editor').addEventListener('cancel',e=>{e.preventDefault();closeEditor()});
$('editor-search').oninput=renderEditorPool;
$('editor-undo').onclick=()=>{mapEdit.tiles=mapEdit.undo.pop();mapEdit.selected=null;editorMessage('Last edit undone.');renderEditor()};
$('editor-reset').onclick=()=>{mapEdit.undo.push(mapEdit.tiles.map(row=>[...row]));mapEdit.tiles=mapEdit.original.map(row=>[...row]);mapEdit.selected=null;editorMessage('Restored the slices from when you opened the editor.');renderEditor()};
$('editor-save').onclick=async()=>{
 if(!mapEdit)return;$('editor-save').disabled=true;
 try{let latest=await api(`/api/rooms/${code}`);if(latest.started)throw Error('The draft has started. Map editing is locked.');if(JSON.stringify(latest.slices.map(s=>s.tiles))!==JSON.stringify(mapEdit.original))throw Error('The saved slices changed. Close and reopen the editor before editing again.');
 room=await api(`/api/rooms/${code}`,{action:'editSlices',tiles:mapEdit.tiles,revision:latest.revision},true);mapEdit=null;$('map-editor').close();render();notice('Custom slices saved. All setup limits passed.');
 }catch(e){editorMessage(e.message+' Your edits have not been saved.')}finally{$('editor-save').disabled=false}
};
