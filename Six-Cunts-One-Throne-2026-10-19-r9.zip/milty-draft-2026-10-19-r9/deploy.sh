#!/usr/bin/env bash
set -euo pipefail
: "${1:?Usage: bash deploy.sh YOUR_GOOGLE_CLOUD_PROJECT_ID}"
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
DRAFT_RELEASE="$(cat VERSION)"
if [[ -n "${2:-}" && "$2" != "$DRAFT_RELEASE" ]]; then
  echo "Wrong source release: expected $2, found $DRAFT_RELEASE. Deployment stopped." >&2
  exit 1
fi
python3 - <<'CHECK'
import pathlib
root=pathlib.Path('.')
assert (root/'static/draft-intro.mp4').stat().st_size>1000000, 'Intro video missing'
assert len(list((root/'static/tiles').glob('*.webp')))>=109, 'Tile artwork missing'
print('Video and tile artwork verified.')
CHECK
echo "Deploying release: $DRAFT_RELEASE"
DRAFT_PROJECT="$1"
DRAFT_REGION="${DRAFT_REGION:-europe-west2}"
gcloud config set project "$DRAFT_PROJECT"
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com firestore.googleapis.com iam.googleapis.com
if ! gcloud firestore databases describe --database='(default)' >/dev/null 2>&1; then
  gcloud firestore databases create --database='(default)' --location="$DRAFT_REGION" --type=firestore-native
fi
for DRAFT_SA in ti4-runtime ti4-build; do
  if ! gcloud iam service-accounts describe "$DRAFT_SA@$DRAFT_PROJECT.iam.gserviceaccount.com" >/dev/null 2>&1; then
    gcloud iam service-accounts create "$DRAFT_SA" --display-name="$DRAFT_SA"
  fi
done
gcloud projects add-iam-policy-binding "$DRAFT_PROJECT" --member="serviceAccount:ti4-runtime@$DRAFT_PROJECT.iam.gserviceaccount.com" --role=roles/datastore.user --condition=None --quiet
gcloud projects add-iam-policy-binding "$DRAFT_PROJECT" --member="serviceAccount:ti4-build@$DRAFT_PROJECT.iam.gserviceaccount.com" --role=roles/run.builder --condition=None --quiet
gcloud run deploy ti4-milty --source . --region="$DRAFT_REGION" \
  --service-account="ti4-runtime@$DRAFT_PROJECT.iam.gserviceaccount.com" \
  --build-service-account="projects/$DRAFT_PROJECT/serviceAccounts/ti4-build@$DRAFT_PROJECT.iam.gserviceaccount.com" \
  --allow-unauthenticated --set-env-vars=STORAGE=firestore \
  --min-instances=0 --max-instances=2 --memory=512Mi --cpu=1 --timeout=60
