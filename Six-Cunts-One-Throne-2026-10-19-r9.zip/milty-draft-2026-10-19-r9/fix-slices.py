"""Correct Milty slice geometry and mobile bounds; retain saved room data."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'engine.py'
s=p.read_text().replace('COORDS=[(0,-1),(0,-2),(1,-2),(1,-3),(2,-3)]','COORDS=[(0,-1),(0,-2),(1,-2),(1,-3),(-1,-2)]')
p.write_text(s)
p=root/'static/app.js';s=p.read_text().replace('const coords=[[0,-1],[0,-2],[1,-2],[1,-3],[2,-3]]','const coords=[[0,-1],[0,-2],[1,-2],[1,-3],[-1,-2]]')
for old in ('-50 -195 200 200','-130 -201 200 193'):
    s=s.replace('viewBox="'+old+'"','viewBox="-160 -201 200 193"')
p.write_text(s)
p=root/'data/tiles.json';tiles=json.loads(p.read_text())
for tile in tiles.values():
    for key in ('anomaly','wormhole'):
        v=tile.get(key);tile[key]=v if isinstance(v,list) else [] if v is None else [v]
p.write_text(json.dumps(tiles,indent=2)+'\n')
print('Corrected slice shape, generator adjacency, exports and mobile bounds. Rooms retained.')
