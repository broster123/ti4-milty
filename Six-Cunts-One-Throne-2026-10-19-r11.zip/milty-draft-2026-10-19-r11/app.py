import os,json,secrets,sqlite3,copy
from pathlib import Path
from flask import Flask,request,jsonify,send_from_directory
from engine import new_room,public,act,digest,FACTIONS,TILES,TE_COMPONENTS,DEFAULT_LIMITS
RELEASE=(Path(__file__).parent/'VERSION').read_text().strip()
app=Flask(__name__,static_folder='static'); app.config['MAX_CONTENT_LENGTH']=16384
LOCAL=os.getenv('STORAGE','firestore')=='sqlite'
if not LOCAL:
    from google.cloud import firestore
    db=firestore.Client()
else:
    DB=os.getenv('SQLITE_PATH','drafts.sqlite3')
    with sqlite3.connect(DB) as c:c.execute('CREATE TABLE IF NOT EXISTS rooms (id TEXT PRIMARY KEY, data TEXT)')
def store_create(code,room):
    if LOCAL:
        with sqlite3.connect(DB) as c:c.execute('INSERT INTO rooms VALUES (?,?)',(code,json.dumps(room)))
    else: db.collection('drafts').document(code).create(room)
def load(code):
    if LOCAL:
        with sqlite3.connect(DB) as c: row=c.execute('SELECT data FROM rooms WHERE id=?',(code,)).fetchone()
        return json.loads(row[0]) if row else None
    snap=db.collection('drafts').document(code).get(); return snap.to_dict() if snap.exists else None
def mutate(code,body,token):
    if LOCAL:
        with sqlite3.connect(DB,timeout=15) as c:
            c.execute('BEGIN IMMEDIATE'); row=c.execute('SELECT data FROM rooms WHERE id=?',(code,)).fetchone()
            if not row: raise LookupError('Room not found.')
            room=json.loads(row[0]); act(room,body,token); c.execute('UPDATE rooms SET data=? WHERE id=?',(json.dumps(room),code)); return room
    ref=db.collection('drafts').document(code)
    @firestore.transactional
    def change(tx):
        snap=ref.get(transaction=tx)
        if not snap.exists: raise LookupError('Room not found.')
        room=snap.to_dict(); act(room,body,token); tx.set(ref,room); return room
    return change(db.transaction())
@app.after_request
def headers(r):
    r.headers['Cache-Control']='no-store'; r.headers['X-Content-Type-Options']='nosniff'; r.headers['Referrer-Policy']='no-referrer'
    r.headers['Content-Security-Policy']="default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; img-src 'self' data:; media-src 'self'; frame-ancestors 'none'"
    return r
@app.errorhandler(Exception)
def error(e):
    from werkzeug.exceptions import HTTPException
    if isinstance(e,HTTPException): return jsonify(error=e.description),e.code
    if isinstance(e,(ValueError,KeyError,TypeError,IndexError)):return jsonify(error=str(e) if isinstance(e,ValueError) else 'Invalid request.'),400
    if isinstance(e,PermissionError):return jsonify(error=str(e)),403
    if isinstance(e,LookupError):return jsonify(error=str(e)),404
    app.logger.exception('Request failed');return jsonify(error='Server error. Try again.'),500
@app.get('/')
def index():return send_from_directory('static','index.html')
@app.get('/api/data')
def data():return jsonify(factions=FACTIONS,tiles=TILES,thundersEdge=TE_COMPONENTS,defaultLimits=DEFAULT_LIMITS,tileArt={p.stem:'/static/tiles/'+p.name for p in (Path(__file__).parent/'static/tiles').glob('*.webp')})
@app.post('/api/rooms')
def create():
    b=request.get_json(); names=b.get('names',[]); te=b.get('thundersEdge',True)
    if not isinstance(te,bool): raise ValueError('Thunder’s Edge setting must be true or false.')
    room=new_room(names,b.get('title',''),te,b.get('bannedFactions'),b.get('sliceLimits'),b.get('orderMode','random'),b.get('factionMode','snake')); token=secrets.token_urlsafe(32); room['host']=digest(token); code=secrets.token_urlsafe(12); store_create(code,room)
    return jsonify(code=code,token=token,room=public(room)),201
@app.get('/api/rooms/<code>')
def read(code):
    room=load(code)
    if room is None:raise LookupError('Room not found.')
    return jsonify(public(room))
@app.post('/api/rooms/<code>')
def update(code):
    token=request.headers.get('Authorization','').removeprefix('Bearer ')
    if len(token)<20:raise PermissionError('Missing player key.')
    return jsonify(public(mutate(code,request.get_json(),token)))
@app.get('/healthz')
def health():return jsonify(ok=True,version=RELEASE)
if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.getenv('PORT',8080)))
