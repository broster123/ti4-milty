# Six Cunts, One Throne — asynchronous TI4 Milty draft

A complete self-hosted six-player draft for friends. **Players do not need to be online together.** Each person claims their name, makes their pick when convenient, closes the page, and returns via the same room link. The server persists every pick. No timer and no accounts.

## Included

- Base game, Prophecy of Kings and Thunder’s Edge tiles; all 30 factions including Council Keleres and the five Thunder’s Edge additions. Thunder’s Edge is enabled by default and can be disabled when creating a room.
- All 20 ordinary Thunder’s Edge map systems (97–111 and 113–117) are in the enabled generator pool: 51 blue and 23 red systems in total. Legendary Mecatol Rex (112) replaces the center rather than joining the slice pool.
- Seven unique five-system slices. Each has three blue and two red systems, no duplicate physical tiles, configurable inclusive minimum/maximum raw resources and influence, configurable per-slice and draft-wide legendary counts, and optional guaranteed matching alpha/beta wormholes. Defaults are 4–16 resources, 4–18 influence, 0–1 legendary per slice, and 0–7 legendaries across the seven offered slices. There are no hidden effective-value or tier restrictions overriding your chosen bounds.
- Server-enforced snake order: 1–6, 6–1, 1–6. Every player chooses one faction, one slice, and one speaker position, in any category order.
- Seat 1 receives the speaker token; remaining seats run clockwise from it.
- Shareable spectator room link, player access keys stored in the browser, host start/undo/regenerate/access recovery, confirmation before picks, searchable factions and system reference, slice statistics, responsive layout, a live 37-hex galaxy view, JSON export.
- Durable Firestore transactions in production; SQLite transactions for local development. Concurrent or stale requests cannot overwrite a successful pick.
- Automatic updates every 15 seconds while visible, immediate reload when returning to the tab. Closed pages need no ongoing connection. There are no email/push notifications in this version.

## Intro video and picking order

The supplied `static/draft-intro.mp4` is embedded above the room details with responsive sizing, native playback controls, inline mobile playback and metadata-only preloading. It does not automatically play sound. It is an H.264/AAC MP4, approximately 7 MB and 34 seconds. The app serves byte ranges for seeking. All rooms use this same intro.

At creation, choose **Randomise at creation** or **Use the player order below**. For manual mode, enter the six names in the desired first-round order. The host can subsequently use **Set picking order** to select each player once in the desired order, apply it, or randomise it. Claimed player access remains attached to that player; reordering does not swap credentials. Order locks once the draft starts. The snake remains forward, reverse, forward. Picking order is independent of the speaker positions that players draft. Existing rooms without a `draftOrder` field retain their original sequence.

## Setup controls

Before creating a room, select factions to ban and set each slice’s resource and influence minimum/maximum. All unbanned enabled factions are offered—there is no random faction shortlist. Leave at least six factions available. Banned factions are rejected by the server as well as hidden from pick choices.

Legendary limits have two scopes: **per slice**, and **the combined pool of all seven offered slices**. To request exactly three legendary planets in that pool, set total minimum = total maximum = 3. Setting per-slice maximum = 0 excludes all draftable legendaries. Setting per-slice minimum = maximum = 1 requires one in each offered slice and therefore seven available legendary planets. The final map uses only six offered slices, so its legendary count depends on which slice is left unpicked. Home-system legends, Mecatol Rex, Fracture planets and off-board expedition components are excluded from these counts.

**Guarantee connected wormholes** includes alpha and beta wormholes in at least three distinct offered slices each. After any one slice is omitted, both wormhole types still appear in at least two distinct retained slices. This guarantees matching exits on the final six-player galaxy, rather than only on the seven-slice preview. It does not promise wormholes are reachable without moving through opponents’ systems.

The host can edit these controls in the room’s **Draft rules → Edit setup and regenerate slices** section until the draft starts. Applying edits regenerates the slices together with the new settings; claims remain. Ordinary regeneration reuses the saved settings. Invalid or unsatisfied requests leave the previous room unchanged. Setup locks when the host starts the draft. Already-started drafts cannot have bans or bounds changed mid-draft.

Resources and influence are the printed totals, including printed space-station values. Effective value is informational. The generator always enforces three blue/two red systems, unique physical tiles, and no within-slice adjacent anomalies. The optional **No adjacent anomalies anywhere in the galaxy** rule additionally checks every pair of offered slices in every relative seat orientation. It keeps anomalies away from home positions too, so Last Bastion/Empyrean anomalous home systems do not break the rule. Thus any six slices can be chosen in any seat arrangement. This stronger rule can make tight resource/legendary ranges harder to satisfy. It uses a bounded five-second search. Obvious impossible inputs are rejected immediately; if a valid solution is not found within the search budget, it asks you to widen limits or try again—it does not silently relax a constraint or claim to have mathematically proved infeasibility.

## Deploy to Google Cloud

You need a Google Cloud project **with billing enabled**, and an account authorised to enable APIs, create service accounts/databases, grant project roles and deploy Cloud Run. Cloud Shell includes `gcloud`; no local Docker installation is needed.

1. Open [Google Cloud Shell](https://shell.cloud.google.com/).
2. Upload this ZIP using Cloud Shell’s upload action, then run:

```bash
unzip Six-Cunts-One-Throne-Milty.zip
cd milty-draft
bash deploy.sh YOUR_PROJECT_ID
```

Replace `YOUR_PROJECT_ID` with the actual project ID, not its display name. The script enables the necessary APIs, creates a default Firestore Native database if absent, creates separate runtime/build service accounts, grants the runtime `roles/datastore.user` and the build account `roles/run.builder`, and deploys from the included Dockerfile. It prints the public HTTPS Cloud Run service URL.

The default region is London (`europe-west2`). For another region:

```bash
DRAFT_REGION=europe-west1 bash deploy.sh YOUR_PROJECT_ID
```

If a default database already exists, the script reuses it. It must be Firestore Native mode. Prefer a dedicated project to isolate its data and IAM permissions; the runtime role gives access to that project’s Firestore data. The account running deployment also needs permission to act as the two service accounts. Organisation policy may prevent public services or IAM changes; an administrator must resolve those restrictions. If a newly created service account is not yet visible, rerun the script after IAM propagation.

Cloud Run, builds, container storage and Firestore can incur charges. The app scales to zero when idle, caps Cloud Run at two instances, and pauses polling in background tabs. Configure a project budget alert in the Cloud Console. This is a private-group application with unguessable room URLs, not an abuse-resistant public draft service: do not publish the service widely without authentication and room-creation rate limiting.

### Run your draft

1. Open the deployed URL, check the six names, faction bans and slice settings, and create a room. Select random order or use the contender input order manually. The host may also choose an exact order in Host controls → Set picking order before starting.
2. Copy the **private host link** and keep it somewhere private. This restores host controls on another device.
3. Copy the ordinary invite link and send it to friends. Anyone who knows that URL can watch and can claim an unclaimed player, so distribute it to your group only.
4. Each friend opens the link and claims their name. Claim your own name too.
5. Once all six names are claimed, the host starts the draft. Slices are then locked.
6. The highlighted player chooses a faction, slice or seat and confirms. Everyone else returns later for their turn; the board tells you who goes next.
7. When all 18 picks are made, view the galaxy and export the complete JSON draft for setup/reference.

Player access is held in browser local storage, so use the same browser/device to return. If someone loses access, the host uses **Release access** next to their name; they can then reclaim it on the new device. Releasing access does not erase picks. A host link is an administrator credential; do not share it as the invite. Losing both the original host browser and the saved host link requires backend recovery. Room exports contain neither host nor player credentials.

## Map and rules notes

Each slice’s tile order follows axial coordinates `(0,-1), (0,-2), (1,-2), (1,-3), (-1,-2)` relative to Mecatol Rex; the home system is `(0,-3)`. The three home-adjacent systems are `(0,-2), (1,-3), (-1,-2)`; `(0,-1)` is adjacent to Mecatol; `(1,-2)` is equidistant between this home and the next clockwise home. Rotate by 60° clockwise for each successive seat. This partitions the standard six-player galaxy into 37 unique positions. The UI labels home tiles by player. Use the faction’s actual home system when setting up the physical game.

Council Keleres is a single draftable faction. After the draft, select an eligible unused faction’s home system using THE TRIBUNII Ω when playing Thunder’s Edge (or the appropriate Codex rule with the expansion disabled); the app does not automatically select that variant. It does not implement faction sheets or special faction setup rules.

The generator avoids adjacent anomalies *inside* a slice. Across-slice anomaly adjacency is flagged in the galaxy view, since independent picks can bring them together; agree any required swaps before physical setup. This is a configurable Milty-style generator, rather than a reproduction of another site’s tier list. Planet traits, wormholes and technologies are retained in the bundled data. Wormhole and legendary constraints are controlled in setup. EFF is the sum of each planet’s larger resource/influence number; tied values are counted once, and RES/INF are separate raw totals. Planet specialties and other raw facts are available in `data/tiles.json`.

### Thunder’s Edge components

Use the Systems & setup tab to inspect every bundled system, printed resource/influence values, specialties, anomalies and wormholes. This also links to the wiki and lists Fracture components.

- Draftable new factions: Last Bastion, Ral Nel Consortium, Crimson Rebellion, Deepwrought Scholarate, and Firmament / Obsidian as one slot. Obsidian is the transformed side of Firmament, not a sixth independently draftable faction.
- Firmament starts with 96A; the reverse is Obsidian’s 96B.
- Crimson uses The Sorrow (94) at its galaxy home position and Ahk Creuxx (118) off board. Both are retained in exported faction metadata.
- The Fracture’s seven systems across tiles 125–127 are catalogued separately and never generated into normal slices. Resolve its entry, ingress and neutral units using your game rules.
- Thunder’s Edge’s expedition planet is a separate 5/1 component that begins off board, not a random starting slice planet. Avernus is also retained as a special faction component reference.
- Hyperlanes 119A/B–124A/B are catalogued as components; the fixed six-player galaxy has no need for them and does not place them.
- This is a Milty draft app, not a full game engine. Breakthrough resolution, expeditions, optional Galactic Events and Twilight’s Fall’s distinct drafting mode are not automated.

The wiki is the requested checking source. The app follows its **Tiles List** for tile IDs, names and resource values, and its **Home Systems**, **Thunder’s Edge** and **The Fracture** pages for setup roles. Some wiki pages disagree on Tiamat’s values: the Tiles List says 2/1, while the Planets and expansion prose tables say 1/2. The artwork update verifies the printed Tiamat tile as **1 resource / 2 influence** and corrects the bundled data accordingly, superseding the earlier Tiles List value. The wiki leaves tile 128 unidentified; no system has been invented for that entry. `data/thunders-edge.json` records sources, these caveats and the separate components.

Existing saved rooms without the new slice settings use the documented default limits when regenerated; already-offered slices are retained until the host regenerates. Existing saved rooms with no expansion setting stay on the original base/PoK rules and cannot draft new factions. Create a new room to enable Thunder’s Edge; old rooms and picks are not silently changed.

## Local use / verification

Python 3.12 recommended. The only local runtime requirement is Flask; Firestore is not required for SQLite mode.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
STORAGE=sqlite python app.py
```

Open `http://localhost:8080`. To let friends on the same LAN connect, use this computer’s LAN IP and allow port 8080 in its firewall. Do not use Flask’s development server for public hosting.

```bash
python -m unittest -v test_app.py
node --check static/app.js
```

Tests cover the full 18-pick draft with separate clients between picks, turn order, duplicate picks, stale writes, simultaneous claims, host permissions, undo, access recovery, 100 slice generations and complete galaxy geometry. Additional checks cover all five new factions, exact expanded tile pools, special-tile exclusion, disabling the expansion, legacy-room compatibility, input validation and multi-icon/space-station specialty accounting. Setup tests cover resource/influence upper and lower bounds, exact/zero/per-slice legendary counts, every possible omitted slice with matching wormholes, faction-ban enforcement, immutable settings after start, regeneration with saved constraints, and atomic rejection of invalid setup changes. These exercise the SQLite persistence path; the deployed Firestore adapter uses the official server transaction library and should be smoke-tested in your project before your first real draft. Browser visual QA was not available in the build environment.

## Files and architecture

- `app.py`: Flask HTTP API and static hosting, with interchangeable transactional stores.
- `engine.py`: generation, validation, public-state redaction and draft state machine.
- `static/`: dependency-free browser UI; no third-party scripts or fonts; tile artwork is bundled locally.
- `data/tiles.json`: bundled factual base/PoK/Thunder’s Edge system data. `data/thunders-edge.json` catalogues special components and provenance.
- `Dockerfile`, `deploy.sh`: Cloud Run deployment.
- `test_app.py`: automated integration and rules checks.

Rooms are stored in Firestore collection `drafts`; they have no automatic expiry. Delete obsolete room documents in Firestore when no longer needed. Never set `STORAGE=sqlite` on Cloud Run: its local filesystem is ephemeral and not shared between instances. No Firestore browser SDK is used; clients cannot read Firestore directly and the database should not have public client rules.

## Credits and references

Unofficial fan work, not affiliated with Fantasy Flight Games. Twilight Imperium and its game content belong to their respective owners. System/planet facts adapted from [KeeganW’s TI4 Map Generator](https://github.com/KeeganW/ti4/blob/master/src/data/tileData.js), retrieved 15 October 2026; the factual system dataset was extended with Thunder’s Edge and corrected/checked against the wiki; tile artwork is bundled from the same project with attribution; no upstream application source is bundled. Faction spelling normalised for L1Z1X.

Google documentation used for deployment:
- [Cloud Run deployment from source](https://docs.cloud.google.com/run/docs/deploying-source-code)
- [Firestore database creation](https://docs.cloud.google.com/sdk/gcloud/reference/firestore/databases/create)
- [Cloud Run public access](https://docs.cloud.google.com/run/docs/authenticating/public)
- [Firestore transactions](https://firebase.google.com/docs/firestore/manage-data/transactions)

Wiki references checked for the Thunder’s Edge update, 15 October 2026:
- https://twilight-imperium.fandom.com/wiki/Tiles_List
- https://twilight-imperium.fandom.com/wiki/Home_Systems
- https://twilight-imperium.fandom.com/wiki/Thunder%27s_Edge
- https://twilight-imperium.fandom.com/wiki/The_Fracture
- https://twilight-imperium.fandom.com/wiki/The_Council_Keleres

## Mobile rendering hotfix

The slice SVG bounds now contain all six hexes, including the home placeholder, on every viewport. Optional anomaly/wormhole fields are normalised to arrays (including off-board Creuss and Mallice records), preventing the system catalogue from aborting with a JavaScript error. Existing room documents and picks are unchanged. To patch an earlier extracted release in place, place `fix-mobile.py` in its `milty-draft` directory, run `python3 fix-mobile.py`, and redeploy with the usual script. Regression checks cover the shape of every system record and every slice hex vertex against the SVG bounds.

## Slice topology correction

The corrected Milty shape has three home-adjacent systems, one equidistant and one next to Mecatol. The generator, slice preview, galaxy and JSON export use this same shape. The old fifth position `(2,-3)` was wrong and is now `(-1,-2)`. Existing rooms retain their tile IDs and picks; their display and exports use the corrected positions. If you already generated a lobby, regenerate its slices before starting to reapply anomaly-adjacency checks to the corrected topology. An active draft keeps its tiles; review any newly adjacent anomalies in the galaxy view. `fix-slices.py` applies the correction to an earlier extracted copy and includes the data normalization hotfix. Tests independently verify three neighbors of home, one neighbor of Mecatol, the equidistant distances, complete 37-position coverage, matching browser/server geometry and unclipped hex vertices.

Additional tests cover manual and random picking order, claim preservation while reordering, all 18 turns after a custom order, order locking, global anomaly safety under every relative rotation including home systems, video byte-range delivery, and JavaScript syntax.

## Tile artwork update

Slice and galaxy hexes now use locally bundled WebP system artwork, rather than text-only geometric placeholders. Tile art has the original flat-top geometry; the screen-coordinate transform and all view bounds were updated together while retaining the same axial Milty coordinates. Slice previews are oriented with the home placeholder below the systems. Selected faction home systems also use art in the galaxy.

Tap a system (or its numbered chip) to open a larger image and readable planet facts. Keyboard users can focus a system and press Enter or Space. The reference catalogue has thumbnails. Controls remain separate from selecting a draft pick; inspecting art never commits a choice. All ordinary base/PoK/TE draft systems and all draftable faction-home/gate systems have local art. The Obsidian reverse side 96B has no image in the source set and is explicitly shown as a text reference, rather than substituted with the Firmament side.

109 WebP assets (approximately 2.2 MB total) are served from `static/tiles/`. Provenance, credit and SHA-256 hashes are recorded in `data/tile-art-sources.json`. Game art belongs to Fantasy Flight Games / respective rights holders; this is an unofficial fan tool. Images came from https://github.com/KeeganW/ti4/tree/master/public/tiles .

Tiamat’s printed image shows 1 resource / 2 influence. The earlier structured record had these reversed; this update fixes it. Public room responses recalculate slice statistics from current planet facts, so saved displays cannot retain the incorrect values. Existing picks and tile IDs remain intact; regenerate a waiting lobby if you want its configured bounds checked against the corrected values.

## Release identity

Current release: **2026-10-16-r7**. Each future download uses a new release filename and a separate extraction directory. The footer and `/healthz` report the installed version. The deploy script prints its source version, verifies the intro video and tile artwork, and accepts an optional second argument specifying the expected release; a mismatch stops deployment. Existing draft data stays in Firestore independently of the extracted source folder.

## r8 — planet/system exclusions

In setup, open **Exclude planet systems**, search by planet name or tile number, and tick any unwanted systems. Legendary systems appear first, marked with a star. For example, excluding Industrex excludes tile 115 from all slices. Whole tiles are removed; one planet cannot be removed from a multi-planet tile independently. All enabled ordinary blue/red systems can be excluded, including anomalies and empty systems; faction homes, Mecatol, and special off-board components are not in this list.

Exclusions are saved in the room and reused for all regenerations. The host may edit them before starting by applying setup and regenerating. Started drafts remain locked. Validation uses the filtered pool for tile counts, legendary availability, resource/influence feasibility and matching wormholes; conflicting settings fail without modifying the saved room. Existing rooms default to no exclusions. To avoid Industrex, tick **Industrex · #115 ★**. If you demand every available legendary planet, Industrex is necessarily included until you exclude it and lower that total.

Release: **2026-10-16-r8**. Extract into the uniquely named r8 directory and deploy with expected version `2026-10-16-r8`. The video, artwork and all previous features are included.

## r9 — optional overall strength balancing

Release **2026-10-19-r9** adds **Balance overall slice strength**, off by default in both new and existing rooms. Ordinary generation is unchanged when it is off. The host may switch it on in setup, or in an existing waiting room by applying setup and regenerating. Started drafts remain locked.

When enabled, the app evaluates up to 200 complete valid sets under a shared five-second search budget and keeps the closest score distribution. It minimises `(score range + 0.35 × score standard deviation) / mean score`; it does not force similar resource and influence totals. Every candidate must still satisfy all configured ranges, legendary counts, exclusions, unique tiles, anomaly rules and wormhole guarantees. The score is a faction-neutral **design heuristic**, not an empirical win-rate model or a promise of equal gameplay strength. Scoring constants are explicit in `engine.py`.

### Model overall-v1

- Economy counts each planet’s larger resource/influence value once. It never adds both full values together. Ties split evenly only in the explanatory opportunity-cost allocation.
- Location multiplier: 1.00 for home-adjacent systems, 0.85 for the system beside Mecatol, 0.65 for the contested equidistant system.
- Access multiplier: supernova 0, asteroid field 0.85, nebula 0.90, gravity rift 0.95, otherwise 1. These approximate difficulty for a generic faction; faction-specific exceptions are not simulated.
- Near-home economy adds 0.25 times its accessible opportunity-cost value.
- Ordinary planets add 0.35 times their access multiplier; space stations do not receive this planet/objective bonus. Each distinct planet trait adds 0.40.
- Each accessible tech color contributes up to 0.65 for its first icon, then 0.20 for repeats, adjusted for access.
- Legendary estimates, multiplied by access: Primor 1.50, Hope’s End 1.75, Faunus 1.50, Garbozia 1.25, Emelpar 1.50, Tempesta 1.25, Industrex 1.75. These rough weights are deliberately visible rather than treated as objective valuations.
- Route adjustment checks the cheapest path from home to Mecatol through the five offered systems. Supernovas block this estimated route; asteroid fields add 0.50 cost, nebulae 0.35 and gravity rifts 0.20 per entered system. Cost above a three-system route is penalised by 0.60 per excess cost; no internal route receives -2.50. Outside-slice detours, wormhole shortcuts, actual fleets, faction powers, starting technology and movement timing are not assumed.

Each slice shows **Estimated strength** with an expandable breakdown. The room reports how many valid sets were compared and the score spread (strongest minus weakest, divided by the average). No fixed maximum score spread is guaranteed: tight custom rules or the time budget may limit the available choices. If only one valid set was found, the comparison count is one; no balancing improvement is implied. Existing offered maps are never silently regenerated.

Tests cover optional/default-off behaviour, location weighting, opportunity-cost accounting, blocked routes, seeded best-of-candidates improvement, all user constraints, persistence across regeneration, toggling off, and invalid inputs.
